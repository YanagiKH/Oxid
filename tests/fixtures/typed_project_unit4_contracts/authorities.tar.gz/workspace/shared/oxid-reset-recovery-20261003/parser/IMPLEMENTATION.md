# Unit4 dormant activation groundwork

This is a local implementation snapshot, not public syntax activation or an
independent qualification receipt. The actual public driver remains byte-identical
and still invokes `load_original`.

## File and interface plan

- `src/frontend/parser.rs`: one file-local sticky `project_recovery` boolean,
  set only at existing project grammar entry sites; project synchronizers depend
  on it. Public-field visibility requires Pub followed by a nontrivia Ident.
- `src/frontend/project.rs`: `load_typed(entry, ProjectLimits)` invokes the same
  one-pass ProjectCandidate loader. Existing `load_project_candidate` delegates
  to it. Existing `SyntaxFlavor` and `syntax_flavor()` remain authoritative AST
  facts; failures still return only retained sources, diagnostics and usage.
- `src/frontend/parser/activation_tests.rs`: source-authored old-diagnostic
  parity, denied-grammar migration and original successful AST/node/provenance
  controls. The original nine-case parity test was executed red before repair.
- Existing parser test constructor initializes the new bit; loader tests cover
  original/project AST flavors, zero path/probe limits for syntax-only files,
  retained failed roots and no child discovery after parse failure.

No public driver/options/lexer/AST, route, index, lowering, native target, CLI
switch, source prescan, trial parser, fallback or executable witness changed.

## Recognition and resource ordering

The top-level Pub+Fn/Struct prefix sets the bit after Pub consumption, before
function/record node admission. Module/import node admission remains before
keyword consumption; module Pub+Mod recognition follows its node gate. Field
node admission remains before public-prefix lookahead or consumption. Adjacent
contextual colons set the bit before paths-disabled and non-crate-prefix denials;
qualified-borrow and qualified-field denial sites do the same. Ordinary signature
punctuation, split/comment-separated colons and recovery-only scans never set it.

The new field lookahead reuses the existing `next_kind()` over the lossless token
tape. It runs only at field-position Pub after that field's node gate. Its token
ranges are disjoint; a terminal EOF can be charged to the initiating Pub. No new
allocation, AST node, name-byte scan or namespace debit is introduced. Independent
instrumentation is still needed to qualify the aggregate inspection bound and
recognition/recovery traces; no observer state is included in this snapshot.

## Frozen identities and verification

Base head: 9481918869cfcd0aef6dbf803df1f9e6ec8a16cc
Base tree: e08a7803a82fbf4f817578c598ca79a52b4edf4c
Core manifest: source-inputs-core-v1.json
Core source copy: core-v1/ (118 files)
Patch: core-v1.patch

`baseline-identity.json` retains untouched production identities;
`baseline-reproduction-test.patch` plus `baseline-reproduction-tests.rs` preserve
the before-change test overlay. `baseline-reproduction.*` and `baseline-layout.*`
record expected failing status 101, full actual JSON/human vectors and the
168-byte baseline Parser size on official Rust 1.99.0 x86_64 Linux. All nine
red failures compare actual diagnostic fields/ordering/renderings, never a
process-local source generation. `baseline-diagnostic-differences.json` names
and summarizes the exact nine sources and observed vectors.

Every later check uses one shared target, CARGO_INCREMENTAL=0 and max two Cargo
jobs. Command argv, working directory, toolchain, selected environment, status,
stream hashes and complete streams are retained by run_check.py. Current
completed checks are fmt and all-target/all-feature clippy, both clean, and
182 Python tests with two existing native-receipt prerequisites skipped.
Focused candidate checks now pass: nine original-domain diagnostic controls,
eight intentional grammar-denial migration vectors, and four successful original
AST/node/provenance controls. Candidate Parser layout is also 168 bytes on the
same toolchain/target. All 16 ordinary Rust test binaries pass (783 passing tests, zero
failures and 21 explicitly ignored qualification tests). Release build and public dormancy smoke pass: original run
returns 1; public Pub/Mod remain E0101 parse rejections.

The repository verifier fails at the known published-baseline auxiliary
`tests/fixtures/typed_project_unit3_independent/components/native-driver/auxiliary/tests/fixtures/owned_source/README.md`
relative link to `../../../fixtures/owned_source/batch.ox`. That separately owned
Unit3 package was not edited. Independent Unit4 observer and public/native
qualification remain unrun and separately gated. `checks-core-v1.json` binds all
retained developer receipts to the still-identical 118-file core snapshot.
