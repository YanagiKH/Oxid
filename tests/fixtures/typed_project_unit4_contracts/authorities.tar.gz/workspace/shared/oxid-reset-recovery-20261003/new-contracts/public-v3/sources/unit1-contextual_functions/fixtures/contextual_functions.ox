fn as() -> i32 { return 2; }
fn crate() -> i32 { return 3; }
fn self() -> i32 { return 5; }
fn super() -> i32 { return 7; }
fn main() -> i32 { return as() + crate() + self() + super(); }
