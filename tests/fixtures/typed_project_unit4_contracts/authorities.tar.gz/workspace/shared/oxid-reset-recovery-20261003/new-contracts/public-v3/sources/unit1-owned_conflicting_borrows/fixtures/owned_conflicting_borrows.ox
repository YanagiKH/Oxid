struct S { n: i32 } fn both(a: &mut S, b: &S) -> i32 { return b.n; } fn main() -> i32 { let mut s = S { n: 3 }; return both(&mut s, &s); }
