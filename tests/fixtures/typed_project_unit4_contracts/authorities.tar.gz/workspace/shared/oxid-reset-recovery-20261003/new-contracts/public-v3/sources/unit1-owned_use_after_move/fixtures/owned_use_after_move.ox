struct S { n: i32 } fn take(p: S) -> i32 { return p.n; } fn main() -> i32 { let s = S { n: 3 }; let n = take(s); return s.n + n; }
