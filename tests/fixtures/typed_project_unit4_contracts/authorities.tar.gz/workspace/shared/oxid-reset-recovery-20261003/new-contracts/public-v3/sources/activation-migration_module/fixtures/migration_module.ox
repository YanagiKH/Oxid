mod absent; fn main() -> i32 { return 7; }
