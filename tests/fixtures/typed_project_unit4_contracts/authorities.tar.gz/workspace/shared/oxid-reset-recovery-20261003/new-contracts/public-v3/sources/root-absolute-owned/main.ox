pub struct Item { pub value: i32 }
fn make() -> crate::Item { return crate::Item { value: 9 }; }
fn main() -> i32 { let item: crate::Item = crate::make(); return item.value; }
