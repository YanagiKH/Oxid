fn same(x: Missing) -> i32 { return 1; }
struct A { value: OtherMissing }
fn same() -> i32 { return 2; }
struct A {}
fn same() -> i32 { return 3; }
