use crate::answer as choose; fn answer() -> i32 { return 7; } fn main() -> i32 { return choose(); }
