#!/usr/bin/env python3
"""Validate only authored artifacts and retained sources. No compiler subprocess."""
import base64
import gzip
import hashlib
import json
from pathlib import Path

import generate_contract as gen

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate():
    if not __debug__: raise ValueError("optimized Python is not permitted")
    frozen = (ROOT / "parser-contract-new-v1.json.gz").read_bytes()
    raw = gzip.decompress(frozen)
    contract = json.loads(raw)
    require(gen.canonical(gen.generate()) == raw, "regeneration mismatch")
    identity = json.loads((ROOT / "identity.json").read_bytes())
    require((len(raw), gen.digest(raw)) == (identity["decoded_bytes"], identity["decoded_sha256"]), "decoded identity mismatch")
    require((len(frozen), gen.digest(frozen)) == (identity["gzip_bytes"], identity["gzip_sha256"]), "gzip identity mismatch")
    require(contract["contract_id"] == gen.IDENTITY, "new contract identity mismatch")
    require(not contract["provenance"]["is_recovered_historical_contract"], "historical recovery misclaim")
    require(contract["provenance"]["compiler_invocations"] == 0, "compiler execution must remain zero")
    interface = json.loads((ROOT / "observer-interface.json").read_bytes())
    require(interface["contract_id"] == gen.IDENTITY, "observer binding mismatch")
    require(interface["binding"]["required_platforms"] == contract["required_platforms"], "platform scope mismatch")
    ids, sources, full_vectors, projections, relations = set(), 0, 0, 0, 0

    def check_location(data, path, loc):
        require(set(loc) == {"file_id", "path", "start", "end", "line", "column", "end_line", "end_column"}, "location field drift")
        require(loc["file_id"] == 0 and loc["path"] == path, "wrong file binding")
        require(0 <= loc["start"] <= loc["end"] <= len(data), "out-of-range origin")
        require(loc == gen.location(data, path, loc["start"], loc["end"]), "bad UTF8/scalar location")

    for case in contract["cases"]:
        require(case["id"] not in ids, "duplicate case")
        ids.add(case["id"])
        src, expected = case["source"], case["expected"]
        data = base64.b64decode(src["base64"], validate=True)
        data.decode("utf-8")
        sources += len(data)
        require((len(data), gen.digest(data)) == (src["bytes"], src["sha256"]), "source identity mismatch")
        require(len(data) <= gen.DEFAULTS["source_bytes"], "parser case needs source-reader contract")
        if "non_eof_tokens" in expected:
            tape = gen.token_tape(data)
            require(len(tape) - 1 == expected["non_eof_tokens"], "token ledger drift: " + case["id"])
            require(sum(t["kind"] == "Eof" for t in tape) == expected["eof_tokens"] == 1, "EOF ledger drift")
        if "diagnostics_exact" in expected:
            full_vectors += 1
            require(len(expected["diagnostics_exact"]) <= 100, "diagnostic cap violated")
            for diag in expected["diagnostics_exact"]:
                require(set(diag) == {"schema_version", "edition", "kind", "severity", "code", "stage", "message", "primary", "secondary", "notes"}, "incomplete diagnostic vector")
                require(diag["kind"] == "diagnostic" and diag["severity"] == "error", "invalid diagnostic envelope")
                if diag["primary"] is not None: check_location(data, src["path"], diag["primary"])
                for label in diag["secondary"]: check_location(data, src["path"], label["span"])
        if "first_diagnostic_projection" in expected:
            projections += 1
            projected = expected["first_diagnostic_projection"]
            if projected.get("primary") is not None: check_location(data, src["path"], projected["primary"])
        if "relation_to_original" in expected:
            relations += 1
            require(expected.get("recognized_final") is False, "original parity crossed recognition boundary")
        if expected["result"] == "ok":
            require(expected["diagnostics_exact"] == [], "successful parse has diagnostics")
            require(expected["syntax_flavor"] == ("ProjectSyntax" if expected["recognized_final"] else "OriginalSingleFile"), "success flavor mismatch")
        else:
            require("syntax_flavor" not in expected, "failed parse fabricates successful flavor")
        for scan in expected.get("field_pub_scans_exact", []):
            tape = gen.token_tape(data)
            pub = scan["initiator_token"]
            require(tape[pub]["kind"] == "Pub", "lookahead initiator is not Pub")
            reads = scan["inspected_tokens"]
            require(reads == list(range(pub + 1, reads[-1] + 1)), "lookahead not contiguous")
            require(all(tape[i]["kind"] == "Trivia" for i in reads[:-1]), "lookahead skipped nontrivia")
            require(tape[reads[-1]]["kind"] == scan["terminal_kind"], "lookahead terminal mismatch")
            require((scan["terminal_kind"] == "Ident") == scan["result_is_ident"], "bad Pub recognition predicate")
            require(len(reads) <= len(tape) - 1, "lookahead EOF charge bound violated")
            require(scan["eof_charge_initiator"] == (pub if scan["terminal_kind"] == "Eof" else None), "bad EOF charge")
        if case["id"].startswith("q-35-"):
            location = expected["first_diagnostic_projection"]["primary"]
            prefix = data[:location["start"]]
            require(data[location["start"]:location["end"]] == b"a", "Q35 span does not identify segment")
            start = data.index(b"crate::")
            require(data[start:location["start"]].count(b"::") == 34, "Q overflow is not segment35")
    require(len(ids) == contract["case_count"] == identity["case_count"], "case roster drift")
    require(len([c for c in contract["cases"] if c["category"] == "immutable-original"]) == 31, "lost Unit1 original cases")
    require(len([c for c in contract["cases"] if c["category"] == "intentional-activation"]) == 4, "lost intentional migrations")
    require({"block-frames-64", "block-frames-65", "q-34-nodes-37", "q-34-nodes-36", "q-35-nodes-37-unicode-crlf"} <= ids, "missing boundary controls")
    return {"kind": "source-only-artifact-validation", "contract_id": gen.IDENTITY,
            "decoded_sha256": gen.digest(raw), "case_count": len(ids), "total_fixture_bytes": sources,
            "full_diagnostic_vector_cases": full_vectors, "first_projection_cases": projections,
            "relational_cases": relations, "compiler_invocations": 0,
            "candidate_comparisons": 0, "qualification_result": "not run", "source_only_status": "pass"}


if __name__ == "__main__":
    print(json.dumps(validate(), indent=2))
