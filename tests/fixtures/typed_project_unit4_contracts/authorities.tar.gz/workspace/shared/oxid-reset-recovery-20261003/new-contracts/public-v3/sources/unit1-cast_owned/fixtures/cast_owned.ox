struct S { x: i32 } fn main() -> i32 { let s = S { x: 9 }; return s.x as i32; }
