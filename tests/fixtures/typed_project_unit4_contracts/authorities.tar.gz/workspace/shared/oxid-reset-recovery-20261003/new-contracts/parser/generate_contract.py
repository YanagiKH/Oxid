#!/usr/bin/env python3
"""NEW source-only Unit4 parser contract. Never executes or imports compiler code."""
import argparse
import ast
import base64
import copy
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
IDENTITY = "oxid-unit4-parser-source-contract-20261003-v1"
DEFAULTS = {"source_bytes": 1048576, "non_eof_tokens": 100000,
            "token_bytes": 65536, "nodes": 100000, "q": 34,
            "diagnostics": 100, "expression_height": 64,
            "block_frames": 64, "parameters": 256, "arguments": 256}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(data):
    return base64.b64encode(data).decode("ascii")


def canonical(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True,
                       separators=(",", ":")) + "\n").encode("utf-8")


def read_authorities():
    manifest = json.loads((ROOT / "authorities.json").read_bytes())
    files = {}
    for item in manifest["sources"]:
        data = Path(item["path"]).read_bytes()
        if (len(data), digest(data)) != (item["bytes"], item["sha256"]):
            raise ValueError("authority changed: " + item["id"])
        files[item["id"]] = data
    return manifest, files


def source_expressions(data):
    """Interpret only literal source-building expressions, never execute Python.

    Ignore all imports, function bodies, filesystem code and expectation objects.
    The resulting sources must also match the immutable suite-intent SHA256s.
    """
    env, sources = {}, {}

    def value(node):
        if isinstance(node, ast.Constant) and isinstance(node.value, (str, int, bytes)):
            return node.value
        if isinstance(node, ast.Name):
            return env[node.id]
        if isinstance(node, (ast.Tuple, ast.List)):
            return tuple(value(x) for x in node.elts)
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mult)):
            left, right = value(node.left), value(node.right)
            return left + right if isinstance(node.op, ast.Add) else left * right
        if isinstance(node, ast.JoinedStr):
            return "".join(str(value(x.value)) if isinstance(x, ast.FormattedValue)
                           else value(x) for x in node.values)
        raise ValueError("unsupported source expression " + ast.dump(node))

    def walk(nodes):
        for node in nodes:
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                if isinstance(node.targets[0], ast.Name) and node.targets[0].id == "long":
                    env["long"] = value(node.value)
            elif isinstance(node, ast.For):
                if not isinstance(node.target, ast.Tuple):
                    raise ValueError("unexpected fixture loop")
                names = [x.id for x in node.target.elts]
                for row in value(node.iter):
                    env.update(zip(names, row))
                    walk(node.body)
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                call = node.value
                if isinstance(call.func, ast.Name) and call.func.id == "add":
                    name, source = value(call.args[0]), value(call.args[1])
                    if name in sources:
                        raise ValueError("duplicate fixture " + name)
                    sources[name] = source.encode() if isinstance(source, str) else source
    walk(ast.parse(data).body)
    return sources


def position(data, offset):
    prefix = data[:offset]
    prefix.decode("utf-8")
    return 1 + prefix.count(b"\n"), 1 + len(prefix.rsplit(b"\n", 1)[-1].decode("utf-8"))


def location(data, path, start, end):
    line, column = position(data, start)
    end_line, end_column = position(data, end)
    return {"file_id": 0, "path": path, "start": start, "end": end,
            "line": line, "column": column, "end_line": end_line, "end_column": end_column}


def diagnostic(data, path, code, message, start, end, stage="parse"):
    return {"schema_version": 1, "edition": "typed-preview", "kind": "diagnostic",
            "severity": "error", "code": code, "stage": stage, "message": message,
            "primary": location(data, path, start, end), "secondary": [], "notes": []}


def token_tape(data):
    """Independent lossless lexer for this contract's controlled ASCII grammar.

    Unicode occurs only in comments/whitespace-free strings in these sources.
    This is a fixture counter, not a language parser or a replacement lexer.
    """
    result, i = [], 0
    keywords = {b"pub": "Pub", b"mod": "Mod", b"use": "Use", b"fn": "Fn",
                b"struct": "Struct", b"return": "Return", b"let": "Let", b"mut": "Mut",
                b"true": "True", b"false": "False", b"if": "If", b"else": "Else",
                b"while": "While", b"break": "Break", b"continue": "Continue"}
    while i < len(data):
        start = i
        if data[i:i+1] in b" \t\r\n":
            while i < len(data) and data[i:i+1] in b" \t\r\n": i += 1
            kind = "Trivia"
        elif data.startswith(b"//", i):
            end = data.find(b"\n", i)
            i = len(data) if end < 0 else end
            kind = "Trivia"
        elif data.startswith(b"/*", i):
            end = data.find(b"*/", i + 2)
            if end < 0: raise ValueError("unterminated controlled comment")
            i, kind = end + 2, "Trivia"
        elif 65 <= data[i] <= 90 or 97 <= data[i] <= 122 or data[i] == 95:
            i += 1
            while i < len(data) and (65 <= data[i] <= 90 or 97 <= data[i] <= 122
                                    or 48 <= data[i] <= 57 or data[i] == 95): i += 1
            kind = keywords.get(data[start:i], "Ident")
        elif 48 <= data[i] <= 57:
            i += 1
            while i < len(data) and 48 <= data[i] <= 57: i += 1
            kind = "Number"
        else:
            # Crucially, :: is not in the two-byte operator set.
            i += 2 if data[i:i+2] in (b"->", b"==", b"!=", b"<=", b">=", b"&&", b"||") else 1
            kind = "Colon" if data[start:i] == b":" else "Punctuation"
        result.append({"kind": kind, "start": start, "end": i})
    result.append({"kind": "Eof", "start": len(data), "end": len(data)})
    return result


def variants(text):
    yield "plain", text
    yield "unicode-lf", "//é🦀\n" + text
    yield "unicode-crlf", "/*é🦀*/\r\n" + text.replace("\r\n", "\n").replace("\n", "\r\n")


def generate():
    authorities, files = read_authorities()
    cases = []

    def add(id, category, source, expected, authority, *, seam=None, path="activation.ox", notes=None):
        data = source.encode("utf-8") if isinstance(source, str) else source
        row = {"id": id, "category": category, "source": {"path": path, "bytes": len(data),
               "sha256": digest(data), "base64": encoded(data)}, "expected": expected,
               "authority": authority, "limits": copy.deepcopy(DEFAULTS)}
        if seam: row["seam"] = seam
        if notes: row["notes"] = notes
        cases.append(row)
        return row

    def accepted(recognized, **extra):
        return {"result": "ok", "diagnostics_exact": [], "recognized_final": recognized,
                "syntax_flavor": "ProjectSyntax" if recognized else "OriginalSingleFile", **extra}

    def error(recognized=None, **extra):
        value = {"result": "parse_error", **extra}
        if recognized is not None: value["recognized_final"] = recognized
        return value

    # The baseline asset is an accepted immutable predecessor authority. Its
    # result bytes are retained verbatim, never populated by a candidate run.
    suite = json.loads(files["unit1-intent"])
    baseline = json.loads(files["unit1-results"])
    sources = source_expressions(files["unit1-generator"])
    if len(suite["cases"]) != 35 or len(sources) != 35: raise ValueError("Unit1 roster drift")
    if digest(files["unit1-intent"]) != baseline["source_intent_sha256"]:
        raise ValueError("Unit1 intent binding drift")
    historical_rows = []
    for old in suite["cases"]:
        source = sources[old["name"]]
        if (len(source), digest(source)) != (old["bytes"], old["sha256"]):
            raise ValueError("Unit1 source differs: " + old["name"])
        check = next(r for r in baseline["canonical_results"] if
                     (r["case"], r["operation"], r["format"]) == (old["name"], "check", "json"))
        text = next(r for r in baseline["canonical_results"] if
                    (r["case"], r["operation"], r["format"]) == (old["name"], "check", "text"))
        records = [json.loads(x) for x in base64.b64decode(check["stdout_base64"]).splitlines()]
        diagnostics = [r for r in records if r["kind"] == "diagnostic"]
        if old["group"] == "OriginalSingleFile":
            if old["route"] in ("parse", "lex"):
                expected = {"result": old["route"] + "_error", "diagnostics_exact": diagnostics,
                            "human_diagnostics_base64_exact": text["stderr_base64"]}
                if old["route"] == "parse": expected["recognized_final"] = False
                else: expected["parse_attempts"] = 0
            else:
                expected = accepted(False, relation_to_original=["complete_ast", "local_ids", "node_count", "source_provenance"])
            add("unit1-" + old["name"], "immutable-original", source, expected,
                ["unit1-intent", "unit1-results", "unit1-generator"], path=old["path"],
                notes="Parser/lexer scope only. Later semantic/run observations belong to the separate public contract.")
        else:
            add("unit1-" + old["name"], "intentional-activation", source, accepted(True),
                ["unit1-intent", "rfc0015"], path=old["path"],
                notes="Parser-only acceptance; module loading/resolution/entry checking are separate gates.")
            historical_rows.append({"case": old["name"], "predecessor_diagnostics": diagnostics,
                                    "activated_parser_result": "ok", "future_intent": old["future_intent"]})

    successes = ["", "// pub mod use crate::\r\nfn crate()->i32{return 2;} fn as()->i32{return crate();}",
                 "struct R { n:i32 } fn main()->i32{let r:R=R{n:5};return r.n;}",
                 "fn bool()->bool{return true;} fn i32()->i32{return 1;}"]
    for i, text in enumerate(successes):
        for variant, source in variants(text):
            add(f"retained-original-success-{i}-{variant}", "original-ast-parity", source,
                accepted(False, relation_to_original=["complete_ast", "local_ids", "node_count", "source_provenance"]),
                ["activation-asserts", "typed-preview"])

    parity = ["fn pub() -> i32 { return 0; }\nfn good() -> i32 { return 1; }\n",
              "struct R { pub: i32 }\nfn pub()->i32{return 0;}\n",
              "struct R { pub pub n: i32 }\nfn pub()->i32{return 0;}\n",
              "struct R { pub", "struct R { pub /* trailing trivia */",
              "struct R { n: crate: :T }\nfn pub()->i32{return 0;}\n",
              "struct R { n: crate:/*note*/:T }\nfn pub()->i32{return 0;}\n",
              "fn main()::i32 {}\nfn pub()->i32{return 0;}\n",
              "fn bad(\nmod skipped;\nuse crate::skipped;\npub fn pub()->i32{return 0;}\n"]
    for i, text in enumerate(parity):
        for variant, source in variants(text):
            add(f"retained-original-error-{i}-{variant}", "pre-recognition-parity", source,
                error(False, relation_to_original=["diagnostic_fields_order_count", "json_diagnostic_bytes", "human_diagnostic_bytes"],
                      recognition_transitions_exact=[]), ["activation-asserts", "activation-semantics", "typed-preview"],
                notes="Relational exactness is the retained assertion; no unavailable literal diagnostics are invented.")

    migrations = [
        ("module", "mod ;", "E0100", "expected module name", ";"),
        ("import", "use crate::;", "E0100", "expected item path segment", ";"),
        ("public-field", "struct R { pub n: }", "E0100", "expected `bool`, `i32` or `()` type", "}"),
        ("qualified-scalar", "struct R { n: crate::T }", "E0101", "qualified paths are unavailable in scalar record fields", "crate"),
        ("relative-scalar", "struct R { n: self::T }", "E0101", "qualified paths are unavailable in scalar record fields", "self"),
        ("relative-call", "fn f()->(){ self::f(); }", "E0101", "only absolute item paths beginning with `crate::` are supported", "self"),
        ("qualified-borrow", "fn f()->(){ g(&crate::x); }", "E0101", "qualified borrow places are unavailable in typed-preview", ":"),
        ("qualified-field", "fn f()->(){ x.crate::n; }", "E0101", "qualified field names are unavailable in typed-preview", ":"),
    ]
    for name, prefix, code, message, spelling in migrations:
        text = prefix + "\nfn pub()->i32{return 0;}\nfn good()->i32{return 1;}\n"
        for variant, source in variants(text):
            data = source.encode()
            first, reserved = data.index(spelling.encode()), data.index(b"fn pub") + 3
            diagnostics = [diagnostic(data, "activation.ox", code, message, first, first + len(spelling)),
                           diagnostic(data, "activation.ox", "E0101", "unsupported typed-preview construct `pub`", reserved, reserved + 3),
                           diagnostic(data, "activation.ox", "E0101", "unsupported typed-preview construct `pub`", reserved, reserved + 3)]
            add(f"retained-migration-{name}-{variant}", "sticky-recognition-migration", data,
                error(True, diagnostics_exact=diagnostics), ["activation-asserts", "activation-semantics", "typed-preview"])

    # Fully syntactic assertions: unresolved item names deliberately remain valid
    # parses. These rows do not claim successful semantic checking.
    positives = {
        "module": "mod child;", "public-module": "pub mod child;",
        "import": "use crate::m::f;", "import-contextual-alias": "use crate::as as crate;",
        "public-function": "pub fn f()->(){return;}", "public-struct": "pub struct R {}",
        "public-field": "struct R { pub n:i32, flag:bool, pub empty:(), }",
        "absolute-call": "fn f()->(){crate::m::f();return;}",
        "absolute-value-type": "fn f(x:crate::m::R)->crate::m::R{return x;}",
        "absolute-borrow-type": "fn f(x:&crate::m::R,y:&mut crate::m::R)->(){return;}",
        "absolute-literal": "fn f()->crate::m::R{return crate::m::R{n:1};}",
        "path-surrounding-trivia": "use crate /*a*/ :: /*b*/ m /*c*/ :: /*d*/ f as x;",
        "contextual-path-components": "use crate::crate::as as self;",
        "parenthesized-condition-literal": "fn f()->(){if (test(crate::R{})) {} return;}",
    }
    for name, text in positives.items():
        for variant, source in variants(text):
            add("grammar-" + name + "-" + variant, "project-grammar", source, accepted(True), ["rfc0015", "typed-preview"])

    negatives = {
        "pub-use": ("pub use crate::f;", "E0101", "pub", False),
        "pub-let": ("pub let x = 1;", "E0101", "pub", False),
        "pub-restricted": ("pub(crate) fn f()->(){}", "E0101", "pub", False),
        "repeated-pub": ("pub pub fn f()->(){}", "E0101", "pub", False),
        "nested-mod": ("fn f()->(){mod child;return;}", "E0101", "mod", False),
        "nested-use": ("fn f()->(){use crate::f;return;}", "E0101", "use", False),
        "nested-pub": ("fn f()->(){pub fn g()->(){} return;}", "E0101", "pub", False),
        "inline-module": ("mod child {}", "E0101", "{", True),
        "missing-module-name": ("mod ;", "E0100", ";", True),
        "missing-import-segment": ("use crate::;", "E0100", ";", True),
        "relative-super-call": ("fn f()->(){super::g();}", "E0101", "super", True),
        "relative-module-call": ("fn f()->(){m::g();}", "E0101", "m", True),
        "split-path-space": ("fn f()->(){crate: :g();}", "E0100", ":", False),
        "split-path-comment": ("fn f()->(){crate:/*é*/:g();}", "E0100", ":", False),
    }
    for name, (source, code, spelling, recognized) in negatives.items():
        for variant, transformed in variants(source):
            data = transformed.encode()
            # Offending construct/name/punctuation is fixed by the grammar;
            # message wording and later recovery diagnostics remain unprojected.
            start = data.index(spelling.encode())
            add("denial-" + name + "-" + variant, "bounded-first-error", transformed,
                error(recognized, first_diagnostic_projection={"code": code, "stage": "parse",
                      "primary": location(data, "activation.ox", start, start + len(spelling)), "secondary": []}),
                ["rfc0015", "activation-semantics"],
                notes="First code/stage, offending-construct byte span, empty secondary and recognition are gated. Message/notes/later count and order are outside this row's projection.")

    supplemental_names = {"glob-import", "group-import", "missing-import-alias", "qualified-function-value",
                          "qualified-field-assignment", "qualified-forwarded-borrow"}
    supplemental_rows = [json.loads(line) for line in gzip.decompress(files["unit2-semantic-corpus"]).splitlines()]
    found_supplements = set()
    for inherited in supplemental_rows:
        if inherited["case"] not in supplemental_names: continue
        require_source = inherited["sources"]
        if len(require_source) != 1: raise ValueError("supplement is not parser-local")
        src = require_source[0]
        data = base64.b64decode(src["base64"], validate=True)
        if (len(data), digest(data)) != (src["bytes"], src["sha256"]): raise ValueError("supplement identity drift")
        found_supplements.add(inherited["case"])
        for variant, transformed in variants(data.decode()):
            add("unit2-recognition-" + inherited["case"] + "-" + variant, "retained-denial-recognition-supplement", transformed,
                error(True, first_diagnostic_projection=copy.deepcopy(inherited["expected"]["first_diagnostic"])),
                ["unit2-semantic-corpus", "activation-semantics", "rfc0015"], path=src["path"],
                notes="Retains only the original first-code/stage projection. New recognition=true assertion follows consumed use or adjacent contextual-path grammar; no complete historical recovery vector is claimed.")
    if found_supplements != supplemental_names: raise ValueError("missing retained parser supplements")

    # Recognition order under early node exhaustion. Field controls use a named
    # admission seam rather than guessing an unpreserved predecessor node count.
    for name, source, recognized, kind, order in [
        ("mod", "mod child;", False, "module", ["node_reject"]),
        ("pub-mod", "pub mod child;", False, "module", ["node_reject"]),
        ("use", "use crate::f;", False, "import", ["node_reject"]),
        ("pub-fn", "pub fn f()->(){}", True, "function", ["consume_pub", "recognize", "node_reject"]),
        ("pub-struct", "pub struct R{}", True, "record", ["consume_pub", "recognize", "node_reject"]),
    ]:
        row = add("node-order-" + name, "node-recognition-order", source,
                  error(recognized, first_diagnostic_projection={"code": "E0400", "stage": "parse", "message": "syntax node limit exceeded"},
                        required_order=order, recognition_transitions_count=int(recognized)),
                  ["activation-semantics", "unit2-parser-resources"], seam={"node_limit": 0})
        row["limits"]["nodes"] = 0
    add("node-order-field", "node-recognition-order", "struct R { pub n:i32 }",
        error(False, first_diagnostic_projection={"code": "E0400", "stage": "parse", "message": "syntax node limit exceeded"},
              field_pub_lookahead_calls=0, required_order=["field_node_reject"], recognition_transitions_exact=[]),
        ["activation-semantics"], seam={"reject_node_admission": {"kind": "field", "occurrence": 1}},
        notes="Seam restricts remaining node budget to zero at the named production admission; it must not directly synthesize a diagnostic or alter recognition.")

    for name, following, is_ident in [("ident", " n:i32 }", True), ("ident-trivia", " /*é*/\r\n n:i32 }", True),
                                    ("reserved", " pub n:i32 }", False), ("colon", ":i32 }", False),
                                    ("eof", "", False), ("eof-trivia", " /*é*/\r\n", False)]:
        source = "struct R { pub" + following
        data, tape = source.encode(), token_tape(source.encode())
        pub = next(i for i, t in enumerate(tape) if t["kind"] == "Pub")
        end = pub + 1
        while tape[end]["kind"] == "Trivia": end += 1
        scan = {"initiator_token": pub, "inspected_tokens": list(range(pub + 1, end + 1)),
                "terminal_kind": tape[end]["kind"], "result_is_ident": is_ident,
                "eof_charge_initiator": pub if tape[end]["kind"] == "Eof" else None}
        expected = accepted(True) if is_ident else error(False, relation_to_original=["diagnostic_fields_order_count", "json_diagnostic_bytes", "human_diagnostic_bytes"])
        expected.update(field_pub_scans_exact=[scan], non_eof_tokens=len(tape)-1, eof_tokens=1)
        add("field-prefix-" + name, "field-lookahead", data, expected,
            ["activation-semantics", "typed-preview"], notes="Logical forward scans exclude the initiating Pub read itself; token indices are zero-based lossless-tape indices.")
    add("field-prefix-many", "field-lookahead-aggregate", "struct R{" + ",".join("pub /*é*/ n%d:i32" % i for i in range(256)) + "}",
        accepted(True, field_pub_lookahead_calls=256, field_scans_disjoint=True,
                 field_lookahead_inspections_bound="non_eof_tokens"), ["activation-semantics", "rfc0015"])

    for segments, limit, attempts, fail_at in [(34, 37, 35, None), (34, 36, 33, 34), (35, 37, 34, 35)]:
        path = "crate::" + "::".join(["a"] * (segments - 1))
        source = "fn main()->(){return " + path + "();}"
        expected = accepted(True, nodes_exact=37, reserve_attempts_exact=35) if segments == 34 and limit == 37 else error(True,
            first_diagnostic_projection={"code": "E0400", "stage": "parse", "message": "qualified path segment limit exceeded" if segments == 35 else "syntax node limit exceeded"},
            reserve_attempts_exact=attempts)
        row = add(f"q-{segments}-nodes-{limit}", "q-node-reserve-precedence", source, expected,
                  ["unit2-parser-resources", "rfc0015"], seam={"node_limit": limit, "reserve_fail_at": fail_at})
        row["limits"]["nodes"] = limit
        if segments == 35:
            start = source.index(path) + len("crate::" + "::".join(["a"] * 33)) + 2
            row["expected"]["first_diagnostic_projection"]["primary"] = location(source.encode(), "activation.ox", start, start + 1)
            prefixed = "/*é🦀*/\r\n" + source
            extra = copy.deepcopy(expected)
            prefix_bytes = len("/*é🦀*/\r\n".encode())
            extra["first_diagnostic_projection"]["primary"] = location(prefixed.encode(), "activation.ox", start + prefix_bytes, start + prefix_bytes + 1)
            utf8row = add("q-35-nodes-37-unicode-crlf", "q-node-reserve-precedence", prefixed, extra,
                         ["unit2-parser-resources", "rfc0015", "typed-preview"], seam={"node_limit": 37, "reserve_fail_at": 35})
            utf8row["limits"]["nodes"] = 37

    add("q-count-overflow", "checked-counter-seam", "crate",
        error(result="direct_seam_error", first_diagnostic_projection={"code": "E0400", "stage": "parse", "message": "project syntax count overflow",
                                         "primary": location(b"crate", "activation.ox", 0, 5)},
              path_segment_count_after="usize::MAX", reserve_attempts_exact=0), ["unit2-parser-resources"],
        seam={"direct_operation": "path_segment", "initial_path_segment_count": "usize::MAX", "node_limit": 0,
              "segment_span": [0, 5]}, notes="Direct checked-arithmetic seam; no full-parse recognition assertion applies.")

    reserve_rows = [("absolute path segments", 1, 24, 4, 9), ("absolute path segments", 2, 24, 11, 12),
                    ("absolute paths", 1, 40, 4, 12), ("import declarations", 1, 56, 0, 13), ("import items", 1, 16, 0, 13)]
    for fail in range(1, 6):
        selected = reserve_rows[fail - 1]
        trace = [{"kind": r[0], "length": r[1], "element_bytes": r[2], "success": i < fail - 1}
                 for i, r in enumerate(reserve_rows[:fail])]
        add("reserve-import-" + str(fail), "retained-reserve-seam", "use crate::f;",
            error(True, diagnostic_count_exact=1, first_diagnostic_projection={"code": "E0400", "stage": "parse",
                  "message": "project syntax allocation failed", "primary": location(b"use crate::f;", "activation.ox", selected[3], selected[4])},
                  reserve_attempts_exact=fail, reserve_trace_exact=trace),
            ["unit2-resources"], seam={"reserve_fail_at": fail},
            notes="Retained Linux x86_64 layout assertions; element_bytes is target-specific, not a new portability claim.")

    for n in (99, 100, 101, 150):
        source = "\n".join("fn f%d()::i32{}" % i for i in range(n))
        data = source.encode()
        diagnostics = []
        cursor = 0
        for i in range(min(n, 100)):
            start = data.index(b"::", cursor)
            diagnostics.append(diagnostic(data, "activation.ox", "E0100", "function requires an explicit return type after `->`", start, start+1))
            cursor = start + 2
        add("diagnostic-cap-" + str(n), "diagnostic-cap", data,
            error(False, diagnostics_exact=diagnostics, relation_to_original=["diagnostic_fields_order_count", "json_diagnostic_bytes", "human_diagnostic_bytes"]),
            ["typed-preview", "unit1-results", "activation-semantics"],
            notes="Repeated independently delimited function starts use the preserved fn synchronizer; diagnostics after the first 100 are omitted, not counted.")

    # Exact ledger controls derive from token grammar and RFC node additions.
    for name, source, tokens, nodes, recognized in [("empty", "", 0, 0, False), ("mod", "mod a;\n", 5, 1, True),
            ("pub-mod", "pub mod a;\n", 7, 1, True), ("import", "use crate::f;", 7, 3, True),
            ("private-empty-fn", "fn f()->(){}", 10, 1, False), ("public-empty-fn", "pub fn f()->(){}", 12, 1, True)]:
        add("ledger-" + name, "node-token-eof-ledger", source,
            accepted(recognized, non_eof_tokens=tokens, eof_tokens=1, nodes_exact=nodes),
            ["unit1-fixtures", "unit2-resources", "rfc0015"])
    for count in (100000, 100001):
        source = b"/**/" * count
        expected = accepted(False, non_eof_tokens=100000, eof_tokens=1, nodes_exact=0) if count == 100000 else {
            "result": "lex_error", "parse_attempts": 0,
            "first_diagnostic_projection": {"code": "E0400", "stage": "lex", "primary": location(source, "activation.ox", 400000, 400004)}}
        add("trivia-token-count-" + str(count), "token-admission", source, expected, ["typed-preview", "unit1-resources"])
    for size in (65536, 65537):
        source = b" " * size
        expected = accepted(False, non_eof_tokens=1, eof_tokens=1, nodes_exact=0) if size == 65536 else {
            "result": "lex_error", "parse_attempts": 0,
            "first_diagnostic_projection": {"code": "E0400", "stage": "lex", "primary": location(source, "activation.ox", 0, size)}}
        add("whitespace-token-bytes-" + str(size), "token-admission", source, expected, ["typed-preview"])

    # Inclusive expression and argument controls are parser-only; f need not be
    # declared and a function need not satisfy all-path return to parse.
    for n in (64, 65):
        source = "fn f()->i32{return " + "+".join(["1"] * n) + ";}"
        expected = accepted(False) if n == 64 else error(False, first_diagnostic_projection={"code": "E0400", "stage": "parse"})
        add("expression-height-" + str(n), "preserved-parser-limits", source, expected, ["typed-preview"])
    for n in (256, 257):
        for kind in ("parameters", "arguments"):
            source = ("fn f(" + ",".join("x%d:i32" % i for i in range(n)) + ")->(){}") if kind == "parameters" else ("fn f()->(){g(" + ",".join(["1"] * n) + ");}")
            expected = accepted(False) if n == 256 else error(False, first_diagnostic_projection={"code": "E0400", "stage": "parse"})
            add(kind + "-" + str(n), "preserved-parser-limits", source, expected, ["typed-preview"])
    for n in (64, 65):
        source = "fn f()->(){" + "while false{" * (n - 1) + "}" * (n - 1) + "}"
        expected = accepted(False) if n == 64 else error(False, first_diagnostic_projection={"code": "E0400", "stage": "parse"})
        add("block-frames-" + str(n), "preserved-parser-limits", source, expected, ["typed-preview"],
            notes="Function body is frame1; each nested while body adds one active statement-block frame. Parser-only, no all-path-return claim.")

    # Source-authored public first-error projections requested by the coordinator.
    for name, source, start, end, code, message, recognized in [
        ("original-reserved-function", "fn pub()->i32{return 1;}", 3, 6, "E0101", "unsupported typed-preview construct `pub`", False),
        ("module-before-reserved-function", "mod child; fn pub()->i32{return 1;}", 13, 16, "E0101", "unsupported typed-preview construct `pub`", True),
        ("module-before-signature-error", "mod child;\nfn main()::i32 {}", 20, 21, "E0100", "function requires an explicit return type after `->`", True),
    ]:
        add("public-root-" + name, "public-root-first-error", source,
            error(recognized, first_diagnostic_projection=diagnostic(source.encode(), "activation.ox", code, message, start, end)),
            ["activation-asserts", "unit1-results", "rfc0015"], notes="Only first diagnostic is projected; this row makes no total diagnostic-count or filesystem observation claim.")

    if len({x["id"] for x in cases}) != len(cases): raise ValueError("duplicate case ids")
    return {
        "schema": "oxid-unit4-parser-source-contract-v1", "contract_id": IDENTITY,
        "status": "source-authored; pending independent review; no candidate comparison authorized by this artifact",
        "provenance": {"authorities_sha256": digest((ROOT / "authorities.json").read_bytes()),
                       "historical_lost_sha256": authorities["historical_lost_parser_contract"]["sha256"],
                       "is_recovered_historical_contract": False, "compiler_invocations": 0,
                       "candidate_result_files_used": 0, "candidate_implementation_used_as_oracle": False,
                       "fixture_materialization": "Restricted static AST interpretation of source expressions; every result matches the retained suite-intent source hash"},
        "default_limits": DEFAULTS, "required_profiles": ["debug", "release"],
        "required_platforms": [{"os": "linux", "architecture": "x86_64", "pointer_width": 64,
                                "rust_target": "x86_64-unknown-linux-gnu"}],
        "platform_applicability": "Every case requires the declared actual execution host/target tuple. Determine it from normalized runtime and compiler target evidence, never fixture labels or note text. A mismatch is unsupported applicability, never a pass; no other host/target qualification is claimed.",
        "case_count": len(cases), "category_counts": dict(sorted(Counter(x["category"] for x in cases).items())),
        "global_invariants": [
            "Every reached parser starts recognition=false; it is sticky and can transition false->true at most once.",
            "Recovery token scanning never sets recognition; neither textual prescans nor mode selection can set it.",
            "Success flavor is determined by consumed project grammar, not by source spelling; failures return no AST/flavor.",
            "Module/import node admission precedes keyword consumption and recognition, including pub mod.",
            "Top-level pub+fn/struct consumes pub and recognizes before the function/record node admission.",
            "A field node gate precedes field Pub lookahead; only next-nontrivia Ident enables public-field consumption/recognition.",
            "Adjacent contextual colons recognize before paths-disabled/non-crate-prefix denial, including qualified-borrow/field denials.",
            "Ordinary signature colons, split/comment-separated delimiters and recovery-only scans never recognize.",
            "Q checked-add and Q>34 rejection precede segment node charge and append/reserve; rejected nodes never append.",
            "Each colon in :: remains a separate non-EOF token. One real EOF per source is stored but excluded from token ledger.",
            "All diagnostics use original UTF-8 bytes and one-based Unicode scalar columns; LF alone starts each line.",
            "The extra field-Pub forward-lookahead ranges are pairwise disjoint; each terminal EOF inspection is charged to its initiating Pub, so these logical extra inspections <= non-EOF tokens.",
            "No new field-prefix lookahead allocates, appends AST entries, scans identifier bytes, or debits namespace work.",
            "All emitted diagnostics <=100; omitted errors are not a total-error-count estimate.",
        ],
        "historical_migrations": historical_rows, "cases": cases,
        "non_claims": ["No reconstruction or equivalence claim to the lost old parser contract.",
                       "No candidate execution, qualification receipt, activation or universal language proof.",
                       "A first_diagnostic_projection constrains only supplied fields; it is never a wildcard full-vector assertion.",
                       "Relational original/project parity does not by itself catch a shared implementation regression; immutable baseline literal/public gates remain required.",
                       "The field lookahead bound is not a bound on all parser token reads or total CPU time.",
                       "Source/loader/index/public/native coverage is separate; parser success does not imply semantic success."]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="Read-only exact regeneration check")
    args = parser.parse_args()
    if not __debug__: raise SystemExit("optimized Python is not permitted")
    contract = generate()
    raw = canonical(contract)
    packed = gzip.compress(raw, compresslevel=9, mtime=0)
    products = {"parser-contract-new-v1.json.gz": packed,
                "roster.json": canonical({"contract_id": IDENTITY, "cases": [{"id": x["id"], "category": x["category"], "source_sha256": x["source"]["sha256"]} for x in contract["cases"]]})}
    summary = {"contract_id": IDENTITY, "decoded_bytes": len(raw), "decoded_sha256": digest(raw),
               "gzip_bytes": len(packed), "gzip_sha256": digest(packed), "case_count": contract["case_count"],
               "category_counts": contract["category_counts"], "generator_sha256": digest(Path(__file__).read_bytes()),
               "authorities_sha256": digest((ROOT / "authorities.json").read_bytes()),
               "compiler_invocations": 0, "candidate_comparisons": 0, "independent_review": "pending"}
    products["identity.json"] = canonical(summary)
    for name, data in products.items():
        path = ROOT / name
        if args.check:
            if path.read_bytes() != data: raise ValueError("generated artifact mismatch: " + name)
        else: path.write_bytes(data)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
