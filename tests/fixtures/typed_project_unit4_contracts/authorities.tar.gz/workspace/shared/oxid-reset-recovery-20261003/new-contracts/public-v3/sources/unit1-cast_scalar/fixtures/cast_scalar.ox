fn main() -> i32 { return (6 + 3) as i32; }
