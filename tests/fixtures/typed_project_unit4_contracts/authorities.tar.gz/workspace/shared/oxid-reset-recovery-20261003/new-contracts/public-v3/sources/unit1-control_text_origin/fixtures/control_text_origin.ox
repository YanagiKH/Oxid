fn main() -> i32 { /*[31m*/ return absent; }
