fn main() -> i32 { while true {} return 0; }
