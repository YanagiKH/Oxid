fn bool() -> i32 { return 4; } fn i32() -> i32 { return 9; } fn main() -> i32 { return bool() + i32(); }
