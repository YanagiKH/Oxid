fn main() -> i32 { let as = 2; let crate = 3; let self = 5; let super = 7; return as + crate + self + super; }
