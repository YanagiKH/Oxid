# New source-only Unit4 parser contract

This is a newly authored qualification contract, identity
`oxid-unit4-parser-source-contract-20261003-v1`. It is **not** the lost historical
`parser-cases-v1.json` whose historical SHA256 was
`2c2b44cf895c2499821a3cc7ab31f6244840a8a44e876a0f82006d84e1f2ed71`.
There is no historical recovery, byte equivalence, complete old-roster coverage,
compiler success or public activation claim.

`identity.json` binds the compressed artifact and its exact decoded UTF-8 JSON
bytes. `parser-contract-new-v1.json.gz` is the complete expected corpus;
`roster.json` provides case names/categories/source identities. Deterministic
generation uses canonical sorted JSON, UTF-8, one final LF and gzip mtime zero.
The generator and every permitted authority file are SHA256-bound. Neither the
generator nor validator imports or runs compiler code.

`package-freeze.json` additionally binds the complete roster, comparison interface,
README, validator and source-only validation receipt. Its own SHA256 must be
recorded by the coordinator and every later adapter. No bound package file can
change under that freeze without a new reviewed package identity.

## Authority and scope

`authorities.json` lists the only admitted expectation authorities:

- RFC0015 at `rfcs/0015-bounded-typed-projects.md` and `spec/typed-preview.md`
- Retained activation semantics and source-authored activation assertions
- Immutable Unit1 compatibility source intent, source recipes and accepted exact
  predecessor expectation bytes, plus source-authored token/node/EOF assets
- Retained Unit2 source assertions for Q/node/resource admission and reserves

The Unit1 source files are absent from the published checkout. The generator
statically interprets only their retained source expressions, then verifies all
35 sources against immutable suite-intent lengths and SHA256s. It never executes
the original fixture generator or writes into the predecessor package. The seven
original parser/lexer failure cases copy full literal diagnostic vectors and
human diagnostic bytes from its accepted baseline asset. The 24 original
parser-success cases retain full AST/ID/node/provenance equality requirements,
including cases whose later resolution/type/ownership/runtime stages reject.
The public contract separately preserves their full public behavior.

Historical execution claims in IMPLEMENTATION.md are not authority. Its admitted
scope is grammar recognition, recovery, field-prefix lookahead and resource
ordering only. Candidate production Rust and candidate output are not expectation
inputs. During discovery a broad metadata search also displayed embedded old
lifecycle derivation/additive-patch snippets in a checkpoint metadata file; those
snippets were excluded from all expectation derivations and the authority list.

## What each projection means

`diagnostics_exact` fixes every field and the complete ordered vector/count.
`human_diagnostics_base64_exact` fixes complete actual human-rendering bytes.
`relation_to_original` fixes exact equality of both independently observed modes
at the same immutable source generation; it does not invent lost literal values.
Such a relational check cannot alone detect a shared regression in both modes,
so the immutable literal and public predecessor gates remain necessary.

`first_diagnostic_projection` fixes exactly the listed first-error fields.
Unspecified prose/notes, later errors and total count are explicitly unclaimed.
The global 100-diagnostic cap and valid byte/scalar origins still apply. These
bounded projections must not be reported as full diagnostic-vector qualification.
On failed parses the sticky recognition bit is observable, but there is no
successful AST or syntax flavor. Recognition is never inferred from final errors.

The preserved eight project-denial sources fix all three diagnostics exactly,
including the repeated later reserved-name diagnostic. Unicode-comment/LF and
Unicode-comment/CRLF variants preserve their syntax and derive origins directly
from the new bytes. Newly added grammar denials use explicit bounded projections.

## Recognition and inspection proof obligations

The observer must establish a false initial sticky bit, at most one false-to-true
transition, and a real grammar trigger for that transition. Recovery scanning
cannot trigger recognition. Ordinary signature `::`, trivia-split delimiters,
and the retained recovery-only prefixes stay in the original compatibility
domain. Earlier recognition stays true through later malformed input.

Module/import node gates precede keyword consumption and recognition, including
`pub mod`. Top-level `pub fn`/`pub struct` consume Pub and recognize before their
ordinary node gates. Field node admission precedes Pub lookahead; its next
nontrivia token must be Ident. EOF, Colon and another Pub do not suffice.
Adjacent contextual colons recognize before the specified path denials.

The extra field-prefix forward scans have disjoint lossless-tape ranges. They
exclude the initiating Pub read itself, include traversed trivia and the final
token, and charge a terminal EOF inspection to the initiating Pub. This proves
the logical extra scan total is at most the number of non-EOF tokens. It does
not assert a numeric bound on all parser token reads, instruction count, memory
allocation overhead or CPU time. Record separate current-token reads honestly.
The operation adds no AST node, allocation, identifier-byte scan or namespace
work debit. `observer-interface.json` specifies required actual event boundaries.

## Resource coverage and boundaries

The exact lowered-node inclusive/over boundary is the preserved Q34 path: 37
nodes pass at limit37; limit36 fails with the retained reserve-order assertion.
Q35 fails its path cap before the node cap and before the denied reserve. The
UTF-8/CRLF variant fixes segment35's byte range independently. Checked path-count
overflow leaves the count at usize::MAX and performs no reserve. A default
100000-node source-reachability claim is not made under the separate token cap.

The five import reserve failures retain exact requested kind/length/element size,
attempt count, error span and failed-before-append ordering on Linux x86_64.
All cases are scoped to actual Linux x86_64, 64-bit pointers, Rust target
`x86_64-unknown-linux-gnu`, in debug and release profiles. The adapter must obtain
that tuple from runtime/compiler evidence. An unsupported tuple is not a pass.
No other platform support is claimed by this finite qualification contract.
The field-node control uses a named admission seam that restricts remaining node
budget at the real field gate; it never guesses an undocumented old node total.

The corpus includes token-count100000/100001, token-byte65536/65537, stored EOF
and colon charges, 99/100/101/150 diagnostic candidates, expression-height64/65,
argument/parameter256/257 and block-frame64/65 controls. Function body counts as
block frame1. The source-byte reader boundary1048576/1048577 belongs to the
coordinator's companion public contract; this parser package receives only
already admitted UTF-8 sources. Module loading, aggregate multi-file ledgers,
index/lifecycle/public/native admission belong to their companion gates.

## Source-only verification and subsequent use

From this directory:

```
python3 -B generate_contract.py --check
python3 -B validate_source_contract.py
```

Generation without `--check` writes only new files in this directory. `--check`
is read-only. Source-only validation checks allowlisted authorities, deterministic
artifact bytes, all source identities, exact diagnostic envelopes and independently
computed UTF-8 locations, every literal token ledger, field scan indices/EOF
charges, Q35 segment selection and required category/boundary inventory.

These checks validate the contract artifact, not the compiler. No compiler has
been built or run and no candidate observation has been compared in authoring.
Independent contract review and coordinator freeze are required before a
separately frozen additive observer executes this corpus. Unsupported observer
fields, unimplemented seams, absent profiles or missing cases are gaps, never
passes. Preserve raw observations and exact source/binary/observer identities.
