#!/usr/bin/env python3
"""Source-only integrity and contract consistency checks; never runs a compiler."""
import gzip,hashlib,json,pathlib,collections
ROOT=pathlib.Path(__file__).resolve().parent/'public-v3'
def h(b):return hashlib.sha256(b).hexdigest()
def load(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def need(c,m):
 if not c:raise ValueError(m)
freeze=load(ROOT/'PUBLIC-FREEZE-v3.json')
for b in freeze['files']+[freeze['generator'],freeze['validator']]:
 p=pathlib.Path(b['path']);data=p.read_bytes();need(len(data)==b['bytes'] and h(data)==b['sha256'],'binding '+str(p))
 if 'decoded_sha256' in b:
  data=gzip.decompress(data);need(len(data)==b['decoded_bytes'] and h(data)==b['decoded_sha256'],'decoded binding '+str(p))
auth=load(ROOT/'authority-bindings-replacement-v3.json')
for b in auth['bindings']:
 data=pathlib.Path(b['path']).read_bytes();need(len(data)==b['bytes'] and h(data)==b['sha256'],'authority changed '+b['path'])
contract=load(ROOT/'public-cli-contract-replacement-v3.json');original=load(ROOT/'original-compatibility-contract-replacement-v3.json.gz')
all_cases=contract['literal_cases']+contract['inherited_negative_and_route_cases']+original['literal_cases']
need(len({r['id'] for r in all_cases})==len(all_cases),'unique cases')
checked_sources=0;rosters=collections.Counter();fullhosts=set(contract['declared_hosts'])
for case in all_cases:
 root=ROOT/case['source_root'];seen=set()
 for s in case['source_files']:
  need(s['path'] not in seen,'duplicate source path');seen.add(s['path'])
  p=root/s['path'];b=p.read_bytes();need(len(b)==s['bytes'] and h(b)==s['sha256'],'source '+case['id']+'/'+s['path']);checked_sources+=1
 need(case['entry'] in seen,'entry missing')
 need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==seen,'complete staged source map '+case['id'])
 need(set(case['required_hosts'])<=fullhosts and case['required_hosts'],'case hosts')
 for op in case.get('observations',case.get('operations',[])):
  hosts=set(op.get('required_hosts',case['required_hosts']));need(hosts and hosts<=fullhosts,'op hosts')
  need(op['argv'][0]=='{oxid}' and op['argv'][2]==case['entry'],'argv binding')
  need(op['argv'][1] in ['check','run','compile'],'operation')
  for host in hosts:
   rosters[host]+=len(contract['profiles'])
  if 'status' in op:
   need(op['status'] in [0,1,2],'status')
   need(op['directory_delta']==(['out.bin'] if op['status']==0 and op['argv'][1]=='compile' else []),'output policy')
   if op['status']==0 and op['argv'][1]=='compile':need(case.get('native_execution') is not None,'native envelope')
  if '--message-format=json' in op['argv'] and 'stdout' in op:
   records=[json.loads(x) for x in op['stdout'].splitlines()]
   need(records[-1]['kind']==op['argv'][1]+'-summary','summary kind')
   need(records[-1]['errors']==len(records)-1,'summary count')
 if 'expected_lifecycle' in case:
  e=case['expected_lifecycle'];need(all(v in [0,1] for v in e.values()),'phase no retry')
  for a,c in [('checker_attempts','checked_program_completions'),('route_attempts','route_completions'),('index_attempts','index_completions')]:need(e[c]<=e[a],'completion bound')
p=load(ROOT/'predecessor-public-projections-replacement-v3.json.gz');need(len(p['rows'])==3755,'predecessor count');need(len({(r['family'],r['id']) for r in p['rows']})==3755,'predecessor uniqueness')
need(collections.Counter(r['family'] for r in p['rows'])=={'Unit2':3603,'Unit3':152},'predecessor corpus completeness')
life=load(ROOT/'lifecycle-contract-replacement-v3.json.gz');need(len(life['heldout_cases'])==15,'heldout completeness');need(len(life['public_cases'])==len(contract['literal_cases'])+len(contract['inherited_negative_and_route_cases']),'public lifecycle complete')
coreby={r['id']:r for r in contract['literal_cases']+contract['inherited_negative_and_route_cases']}
for row in life['public_cases']:
 c=coreby[row['id']];obs=c.get('observations',c.get('operations',[]));need(len(obs)==len(row['observations']),'lifecycle observation completeness')
 for i,(want,got) in enumerate(zip(obs,row['observations'])):
  need(got['observation_index']==i and got['argv']==want['argv'] and got['required_hosts']==want.get('required_hosts',c['required_hosts']) and got['profiles']==contract['profiles'],'lifecycle per-observation scope')
 need(row['expected_flavor'] in ['original','project',None],'lifecycle flavor')
for r in life['heldout_cases']:
 need(all(x in [0,1] for x in r['expected_lifecycle'].values()),'heldout no retries')
 for b in r['files_hex'].values():bytes.fromhex(b)
old_fixture=load(pathlib.Path('/workspace/scratch/8266abf56995/oxid-recovery-main/tests/fixtures/typed_project_unit1_independent/expected-fixtures.json'))
oldby={x['id']:x for x in old_fixture['fixtures']}
for new,old in [('child-invalid-utf8','invalid_utf8'),('child-oxbc-before-utf8','oxbc_before_utf8'),('child-lex-ascii','child_lex_before_sibling')]:
 c=coreby[new];o=oldby[old];need(c['entry']==o['entry'] and c['source_files']==o['sources'],'exact preserved source fixture')
 e=c['literal_accepted_expected_projection'];want=o['expected'];need(e['code']==want['code'] and e['stage']==want['stage'] and all(e['location'][k]==want['primary'][k] for k in ['file','start','end']),'preserved source diagnostic')
bytecase=coreby['source-byte-exact'];b=(ROOT/bytecase['source_root']/'main.ox').read_bytes();inv=bytecase['source_byte_boundary_inventory']
base=b''.join(bytes.fromhex(x) for x in inv['base_token_bytes_hex']);tail=b[len(base):];need(b.startswith(base) and len(b)==1048576,'exact source byte inventory')
offset=0
for n in inv['padding_token_lengths']:
 piece=tail[offset:offset+n];need(len(piece)==n and 4<=n<=65536 and piece[:2]==b'/*' and piece[-2:]==b'*/' and set(piece[2:-2])<={32},'bounded comment token');offset+=n
need(offset==len(tail),'all padding accounted')
need(inv['with_eof_token_count']==len(inv['base_token_lengths'])+len(inv['padding_token_lengths'])+1 and inv['with_eof_token_count']<=100000,'EOF token inventory')
guard=load(ROOT/'output-guards-contract-replacement-v3.json');need(len(guard['occupied_controls'])==10,'guard count');need(guard['concurrent_publication']['payload_sha256']==h(bytes.fromhex(guard['concurrent_publication']['payload_hex'])),'race payload')
report={'status':'PASS_SOURCE_ONLY_INTEGRITY','compiler_invocations':0,'candidate_outputs_read':0,'bound_authorities':len(auth['bindings']),'source_file_bindings_checked':checked_sources,'core_and_original_cases':len(all_cases),'public_invocations_by_host_in_both_profiles':dict(rosters),'preserved_unit2_rows':3603,'preserved_unit3_rows':152,'freeze_sha256':h((ROOT/'PUBLIC-FREEZE-v3.json').read_bytes()),'validation_limit':'Artifact integrity/schema/count/lifecycle consistency only; not semantic independent approval and not a compiler pass.'}
print(json.dumps(report,indent=2))
