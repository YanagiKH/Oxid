use crate::helper as main;
fn helper() -> i32 { return 8; }
