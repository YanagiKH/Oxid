struct S { n: i32 } fn main() -> i32 { let s = S { n: 3 }; s.n = true; return s.n; }
