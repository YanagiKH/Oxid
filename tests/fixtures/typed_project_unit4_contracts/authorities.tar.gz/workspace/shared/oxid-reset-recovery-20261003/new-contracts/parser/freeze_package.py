#!/usr/bin/env python3
"""Freeze/check the complete new source-only contract package, never candidate code."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = ["README.md", "authorities.json", "freeze_package.py", "generate_contract.py", "generation-summary.json",
         "identity.json", "observer-interface.json", "parser-contract-new-v1.json.gz",
         "roster.json", "source-only-validation.json", "validate_source_contract.py"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    identity = json.loads((ROOT / "identity.json").read_bytes())
    rows = []
    for name in sorted(FILES):
        data = (ROOT / name).read_bytes()
        rows.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    value = {"schema": "oxid-unit4-parser-new-package-freeze-v1", "contract_id": identity["contract_id"],
             "decoded_contract_sha256": identity["decoded_sha256"], "files": rows,
             "candidate_compiler_invocations": 0, "candidate_comparisons": 0,
             "independent_review_status": "coordinator must bind a separate independent review to this exact package-freeze SHA256",
             "change_rule": "Any bound-file edit invalidates this freeze. Regenerate/review and bind a new freeze SHA256 before candidate comparison."}
    data = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
    path = ROOT / "package-freeze.json"
    if args.check:
        if path.read_bytes() != data: raise ValueError("package freeze mismatch")
    else: path.write_bytes(data)
    print(json.dumps({"package_freeze_sha256": hashlib.sha256(data).hexdigest(),
                      "decoded_contract_sha256": identity["decoded_sha256"],
                      "files": len(rows), "mode": "check" if args.check else "freeze"}, indent=2))


if __name__ == "__main__":
    main()
