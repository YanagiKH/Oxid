#!/usr/bin/env python3
"""Author new Unit4 expectations only from allowlisted preserved authorities.
No compiler process, current implementation, candidate output, or remote writes.
"""
import base64, collections, gzip, hashlib, json, pathlib, tarfile, tempfile, runpy, contextlib, io
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/workspace/scratch/8266abf56995/oxid-recovery-main')
REC=ROOT.parent
OUT=ROOT/'public-v3'
FX=REPO/'tests/fixtures'
U1=FX/'typed_project_unit1_compatibility'
U2=FX/'typed_project_unit2_independent/semantic'
U3=FX/'typed_project_unit3_independent'
O3=U3/'components/oracles'
HOSTS=['Linux x86_64','macOS x86_64','macOS arm64','Windows x86_64']
NATIVE=['Linux x86_64']
PROFILES=['debug','release']
PHASES=['checker_attempts','checked_program_completions','route_attempts','route_completions','index_attempts','index_completions']
FP=['source_open_attempt','source_open_complete','source_read_attempt','source_read_complete','lex_attempt','lex_complete','parse_attempt','parse_complete']
FULL=dict.fromkeys(PHASES,1); ZERO=dict.fromkeys(PHASES,0); FILE_FULL=dict.fromkeys(FP,1)
BODY=dict(zip(PHASES,[1,0,1,1,1,1])); INDEX=dict(zip(PHASES,[1,0,1,1,1,0]))
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(x))
def bind(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def compact(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def zipped(p,x):b=enc(x);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0));return {**bind(p),'decoded_bytes':len(b),'decoded_sha256':sha(b),'compression':'gzip mtime=0'}
def need(c,m):
 if not c:raise ValueError(m)
def src(name,files):
 target=OUT/'sources'/name
 result=[]
 for path,b in files.items():
  p=target/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  result.append({'path':path,'bytes':len(b),'sha256':sha(b)})
 need({p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()}==set(files),'unexpected staged source '+name)
 return 'sources/'+name,result

def argv(op,entry='main.ox',fmt='json'):
 a=['{oxid}',op,entry,'--edition','typed-preview']
 if op=='compile':a+=['--backend','llvm','--output','out.bin']
 if fmt=='json':a+=['--message-format=json']
 return a

def summary(op,value,success=True,errors=0):
 return {'schema_version':1,'edition':'typed-preview','kind':op+'-summary','success':success,'errors':errors,{'check':'functions','run':'result','compile':'output'}[op]:value}
def line(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n'
def accepted_ops(entry,functions,value,ty='i32',compile=True,hosts=HOSTS):
 rows=[]
 for op in ['check','run']+(['compile'] if compile else []):
  for fmt in ['json','text'] if op!='compile' else ['json']:
   val=functions if op=='check' else ('out.bin' if op=='compile' else {'type':ty,**({'value':value} if ty!='unit' else {})})
   out=line(summary(op,val)) if fmt=='json' else (f'typed-preview check ok ({functions} functions; check only)\n' if op=='check' else (str(value).lower()+'\n' if ty!='unit' else '()\n'))
   rows.append({'argv':argv(op,entry,fmt),'required_hosts':NATIVE if op=='compile' else hosts,'status':0,'stdout':out,'stderr':'','directory_delta':['out.bin'] if op=='compile' else []})
 return rows

def native(value,ty='i32'):
 return {'platform':'Linux x86_64','llvm_version':'19.1.7','opt_level':0,'copy_only_elf':True,'fixture_sources_unavailable':True,'restore_sources_after':True,'status':0,'stdout':str(value).lower()+'\n' if ty!='unit' else '()\n','stderr':''}
def loc(files,path,start,end,file_id=0):
 b=files[path]
 def pos(off):
  prefix=b[:off].decode('utf-8');return prefix.count('\n')+1,len(prefix.rsplit('\n',1)[-1])+1
 ln,col=pos(start);eln,ecol=pos(end)
 return {'file':file_id,'path':path,'start':start,'end':end,'line':ln,'scalar_column':col,'end_line':eln,'end_scalar_column':ecol}
def diag(code,stage,location=None,related=None,message=None):
 d={'code':code,'stage':stage,'location':location,'related_locations':related or []}
 if message is not None:d['literal_message']=message
 return d

def add_success(case_id,files,functions,value,route='scalar',flavor='ProjectSyntax',entry='main.ox',hosts=HOSTS,reason='',compile=True):
 root,manifest=src(case_id,files)
 return {'id':case_id,'source_root':root,'entry':entry,'source_files':manifest,'required_hosts':hosts,'successful_flavor':flavor,'expected_route':route,'expected_function_count':functions,'expected_lifecycle':FULL,'file_counts':{p:FILE_FULL for p in files},'observations':accepted_ops(entry,functions,value,compile=compile,hosts=hosts),'native_execution':native(value) if compile else None,'source_derivation':reason}

# Exact predecessor streams are retained without any diagnostic/whitespace rewrite.
u1=read(U1/'suite-intent.json')
# Execute only the unchanged independent fixture author in isolated temporary storage.
_u1tmp=tempfile.TemporaryDirectory(prefix='unit4-source-author-');U1S=pathlib.Path(_u1tmp.name)
(U1S/'fixtures').mkdir();(U1S/'generate_fixtures.py').write_bytes((U1/'generate_fixtures.py').read_bytes())
with contextlib.redirect_stdout(io.StringIO()):runpy.run_path(str(U1S/'generate_fixtures.py'))
for c in u1['cases']:
 b=(U1S/c['path']).read_bytes();need(len(b)==c['bytes'] and sha(b)==c['sha256'],'independent Unit1 source replay')
results=read(U1/'expected-results.json')['canonical_results'];original=[]
for case in u1['cases']:
 if case['group']!='OriginalSingleFile':continue
 b=(U1S/case['path']).read_bytes();need(sha(b)==case['sha256'],'Unit1 source binding')
 root,manifest=src('unit1-'+case['name'],{case['path']:b})
 obs=[]
 for e in results:
  if e['case']!=case['name']:continue
  obs.append({'argv':argv(e['operation'],case['path'],e['format']),'required_hosts':HOSTS,'status':e['exit_code'],'stdout':base64.b64decode(e['stdout_base64']).decode(),'stderr':base64.b64decode(e['stderr_base64']).decode(),'directory_delta':[],'authority':{'path':str(U1/'expected-results.json'),'case':case['name'],'operation':e['operation'],'format':e['format'],'baseline_record_sha256':e['baseline_record_sha256']}})
 need(len(obs)==4,'Unit1 complete check/run text/json')
 original.append({'id':'unit1-'+case['name'],'source_root':root,'entry':case['path'],'source_files':manifest,'required_hosts':HOSTS,'predecessor_group':case['group'],'source_route_authority':case['route'],'observations':obs,'source_derivation':case['intent'],'lifecycle_scope':'Public bytes only; phase lifecycle remains separately qualified by dedicated heldouts. No unseen phase split is inferred from predecessor process status.'})
need(len(original)==31,'all Unit1 originals')
zipped(OUT/'original-compatibility-contract-replacement-v3.json.gz',{'schema_version':1,'identity':'unit4-original-compatibility-replacement-v3','profiles':PROFILES,'declared_hosts':HOSTS,'literal_cases':original,'inherited_negative_and_route_cases':[],'authority':bind(U1/'expected-results.json'),'excluded_cases':{x['name']:x['future_intent'] for x in u1['cases'] if x['group']!='OriginalSingleFile'},'comparison':'Exact complete status/stdout/stderr, including complete diagnostic prose, order and rendering. No normalization or renamed entry paths.'})

# Published Unit3 source transport is the sole source byte authority for pilots.
requests=[json.loads(x) for x in (O3/'requests.jsonl').read_bytes().splitlines()]
exlines=gzip.decompress((O3/'expected.jsonl.gz').read_bytes()).splitlines(keepends=True)
expected=[json.loads(x) for x in exlines]
qby={x['id']:x for x in requests};eby={x['id']:x for x in expected}
need(len(requests)==len(expected)==152,'all Unit3 rows')
archive={}
with tarfile.open(U3/'source-transport/sources.tar.gz','r:gz') as t:
 for m in t.getmembers():
  need(m.isfile(),'source transport ordinary files only')
  need(not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts,'archive source path')
  archive[m.name]=t.extractfile(m).read()
def u3files(case_id):
 q=qby[case_id];files={}
 for s in q['source_files']:
  b=archive[q['source_root']+'/'+s['path']];need(len(b)==s['bytes'] and sha(b)==s['sha256'],'Unit3 source '+case_id);files[s['path']]=b
 return files
literal=[];inherited=[]
# Deliberate public grammar migrations retain old source bytes and old rows unchanged.
for name,n,value in [('migration_import',2,7),('migration_visibility',1,11),('migration_qualified_call',2,13)]:
 c=next(x for x in u1['cases'] if x['name']==name);b=(U1S/c['path']).read_bytes()
 row=add_success('activation-'+name,{c['path']:b},n,value,entry=c['path'],reason=c['future_intent']);row['predecessor_authority']={'path':str(U1/'suite-intent.json'),'case':name,'unchanged_old_rejection':True};literal.append(row)
# Independently calculated, module-free project syntax must be portable.
literal += [
 add_success('root-public-field',{'main.ox':b'pub struct Item { pub value: i32 }\npub fn main() -> i32 { let item = Item { value: 7 }; return item.value; }\n'},1,7,route='owned',reason='One original function constructs Item.value=7 and reads it; public field changes no operation or value.'),
 add_success('root-public-field-trivia',{'main.ox':'// é🦀\r\npub struct Item { pub /* 雪 */ value: i32 }\r\npub fn main() -> i32 { let item = Item { value: 7 }; return item.value; }\r\n'.encode()},1,7,route='owned',reason='Exact UTF-8/CRLF variant; Pub next nontrivia token is Ident. Comments/line endings alter origins only.'),
 add_success('root-absolute-owned',{'main.ox':b'pub struct Item { pub value: i32 }\nfn make() -> crate::Item { return crate::Item { value: 9 }; }\nfn main() -> i32 { let item: crate::Item = crate::make(); return item.value; }\n'},2,9,route='owned',reason='Absolute root type/call paths resolve original Item/make. make returns value=9.'),
 add_success('root-contextual-absolute-scalar',{'main.ox':b'fn crate() -> i32 { return 4; } fn as() -> i32 { return 6; }\nuse crate::crate as selected;\npub fn main() -> i32 { return selected() + crate::as(); }\n'},3,10,reason='First crate is contextual path root; endpoint crate and as remain ordinary names. 4+6=10.'),
]
pilots=['pilot-scalar','pilot-original-batch','pilot-mechanical-batch','pilot-opaque-batch','pilot-counter','control-owned-entry-id1']
reasons={
 'pilot-scalar':'sum(4) visits i=1,2,3,4; skips i=2, sums 1+3+4=8 and breaks after total>6. choose(false,7,2)=2, so original root main returns 8+2=10. helper=99 and child main(x)=x+1000 are unused and never become entry.',
 'pilot-original-batch':'Six jobs each commit once, each with one retry: checksum=10*(1+2+3+4+5+6)=210, completed=6, retries=6, result=210+600+6=816.',
 'pilot-mechanical-batch':'Visibility/import-only relocation retains original Batch operation schedule: checksum=210, completed=6, retries=6, result=816. Preserve the frozen relocation and fuel correspondence.',
 'pilot-opaque-batch':'make starts (completed,retries,checksum,active)=(0,0,0,true). For each next_job=1..6, first attempt retries and continues, second dispatches commit then breaks. done after job 6 leads stop. relay moves the intact Batch. finish=210+600+6=816. Extra query/update helper calls retain their distinct frozen schedule/fuel.',
 'pilot-counter':'make(4), one increment through &mut Counter, then finish consumes Counter: 4+1=5.',
 'control-owned-entry-id1':'The original root helper occupies DefId0, so root main is DefId1. make(4), increment once and finish return 5. Child main takes and returns Counter and is an ordinary unused function; helper=91 is unused.'}
for case_id in pilots:
 e=eby[case_id];q=qby[case_id];files=u3files(case_id)
 row=add_success(case_id,files,e['function_count'],e['expected']['result'],route=e['route'],flavor='OriginalSingleFile' if case_id=='pilot-original-batch' else 'ProjectSyntax',entry=q['entry'],hosts=HOSTS if case_id=='pilot-original-batch' else NATIVE,reason=reasons[case_id]);row['expected_entry']=e['entry'];row['predecessor_authority']={'request_line_1_based':requests.index(q)+1,'expected_line_1_based':expected.index(e)+1,'expected_line_including_lf_sha256':sha(exlines[expected.index(e)]),'native_required_unchanged':e['native_required'],'budget_cases_and_schedule':'Entire unchanged Unit3 row; public result projection does not replace it.'};literal.append(row)
for case_id in ['negative-imported_main-scalar','negative-imported_main-owned','negative-unused_move_beats_missing_main','control-unused_nominal-false','control-unused_nominal-true','negative-native_recursion-scalar-true','negative-native_recursion-scalar-false','negative-native_recursion-owned-true','negative-native_recursion-owned-false']:
 e=eby[case_id];q=qby[case_id];root,manifest=src(case_id,u3files(case_id))
 row={'id':case_id,'source_root':root,'entry':q['entry'],'source_files':manifest,'required_hosts':NATIVE,'expected_function_count':e['function_count'],'expected_entry':e['entry'],'expected_route':e['route'],'successful_flavor':'ProjectSyntax','expected_lifecycle':BODY if case_id=='negative-unused_move_beats_missing_main' else FULL,'file_counts':{s['path']:FILE_FULL for s in manifest},'operations':[{'argv':argv(op,q['entry']),'required_hosts':NATIVE} for op in ['check','run','compile']],'literal_accepted_expected_projection':e['expected'],'projection_scope':'Complete diagnostic count/order and code/stage/primary/secondary locations; message/label prose and notes are not claimed literal unless separately frozen. Summary schema/status/payload are exact.','predecessor_authority':{'request_line_1_based':requests.index(q)+1,'expected_line_1_based':expected.index(e)+1,'expected_line_including_lf_sha256':sha(exlines[expected.index(e)])}}
 if case_id.startswith('control-unused_nominal'):row['native_execution']=native(4)
 inherited.append(row)
# A root without mod keeps normal discovery-free semantics on every declared host.
files={'main.ox':b'pub fn helper() -> i32 { return 8; }\n'};root,manifest=src('host-no-main',files)
inherited.append({'id':'host-no-main','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':HOSTS,'expected_function_count':1,'expected_entry':None,'expected_route':'scalar','successful_flavor':'ProjectSyntax','expected_lifecycle':FULL,'file_counts':{'main.ox':FILE_FULL},'operations':[{'argv':argv(op),'required_hosts':NATIVE if op=='compile' else HOSTS} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'check':'accept','run':diag('E0600','oir-run'),'native':diag('E0700','native-admission')},'projection_scope':'Exact summary/diagnostic count/code/stage/null origins. Literal entry prose is separately preserved by Unit1 check_without_entry.'})
# Explicit unsupported-host proof: root is parsed but no child source is read.
files={'main.ox':b'mod child;\nfn main() -> i32 { return 1; }\n','child.ox':b'pub fn child() -> i32 { return 2; }\n'};root,manifest=src('host-child-denied',files)
inherited.append({'id':'host-child-denied','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':[x for x in HOSTS if x not in NATIVE],'expected_route':None,'expected_lifecycle':ZERO,'file_counts':{'main.ox':FILE_FULL},'operations':[{'argv':argv(op),'required_hosts':[x for x in HOSTS if x not in NATIVE]} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag('E0005','source',loc(files,'main.ox',4,9))},'projection_scope':'Exactly one policy diagnostic with declaring mod-name origin; nonempty bounded message, no unlicensed exact wording claim. Complete source map retained; child counters absent/zero.'})
# Source-derived missing-child migration has portable source error projection, host policy first off Linux.
c=next(x for x in u1['cases'] if x['name']=='migration_module');files={c['path']:(U1S/c['path']).read_bytes()};root,manifest=src('activation-migration_module',files)
for hosts,code,suffix in [(NATIVE,'E0002','linux'),([x for x in HOSTS if x not in NATIVE],'E0005','nonlinux')]:
 inherited.append({'id':'activation-migration_module-'+suffix,'source_root':root,'entry':c['path'],'source_files':manifest,'required_hosts':hosts,'expected_route':None,'expected_lifecycle':ZERO,'operations':[{'argv':argv(op,c['path']),'required_hosts':hosts} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag(code,'source',loc(files,c['path'],4,10))},'projection_scope':'Exactly one source diagnostic at absent declaration; E0002 host cause prose intentionally nonliteral. No invented child span.','source_derivation':c['future_intent'],'file_counts':{c['path']:FILE_FULL},'child_open_scope':'No successful child open/read. Missing child lookup itself occurs after bounded directory proof on Linux; source_open logical attempt is not asserted because lookup can reject before open.'})

# Root parsing must win before host discovery; recovery tail is not invented.
for case_id,source,start,end in [
 ('host-malformed-root-first',b'mod child; fn pub()->i32{return 1;}',13,16),
 ('host-old-reserved-name',b'fn pub()->i32{return 1;}',3,6),
 ('host-malformed-signature-first',b'mod child;\nfn main()::i32 {}',20,21)]:
 files={'main.ox':source,'child.ox':b'pub fn child() -> i32 { return 2; }\n'} if case_id!='host-old-reserved-name' else {'main.ox':source}
 root,manifest=src(case_id,files)
 first=diag('E0100' if case_id=='host-malformed-signature-first' else 'E0101','parse',loc(files,'main.ox',start,end),message='function requires an explicit return type after `->`' if case_id=='host-malformed-signature-first' else 'unsupported typed-preview construct `pub`')
 inherited.append({'id':case_id,'source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':HOSTS,'expected_route':None,'expected_lifecycle':ZERO,'file_counts':{'main.ox':dict(zip(FP,[1,1,1,1,1,1,1,0]))},'operations':[{'argv':argv(op),'required_hosts':HOSTS} for op in ['check','run','compile']],'expected_public_projection':{'kind':'first-diagnostic-only','status':1,'first_diagnostic':first,'summary_kind_per_operation':True,'summary_success':False,'summary_payload':None,'errors_equals_emitted_diagnostic_count':True,'diagnostic_cap':100,'stderr':''},'projection_scope':'First diagnostic exact code/stage/message/full primary; no claimed later recovery sequence. Later diagnostics must be valid schema and remain within cap. Sources unchanged, no child stage entered and zero tools. Source-only parser review requested separately.'})
# A module-free valid project reaches native host rejection after full checking.
files={'main.ox':b'pub fn main() -> i32 { return 3; }\n'};root,manifest=src('host-native-denied',files)
inherited.append({'id':'host-native-denied','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':[x for x in HOSTS if x not in NATIVE],'expected_function_count':1,'expected_route':'scalar','successful_flavor':'ProjectSyntax','expected_lifecycle':FULL,'file_counts':{'main.ox':FILE_FULL},'operations':[{'argv':argv('compile'),'required_hosts':[x for x in HOSTS if x not in NATIVE]}],'literal_accepted_expected_projection':{'check':'accept','native':diag('E0701','native-toolchain')},'projection_scope':'Native host admission denial after checked program completes. Exact code/stage/null origin, no tools, no output; message wording not specified.'})
files={'main.ox':b'use crate::helper as main;\nfn helper() -> i32 { return 8; }\n'};root,manifest=src('root-imported-main',files)
inherited.append({'id':'root-imported-main','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':HOSTS,'expected_function_count':1,'expected_entry':None,'expected_route':'scalar','successful_flavor':'ProjectSyntax','expected_lifecycle':FULL,'file_counts':{'main.ox':FILE_FULL},'operations':[{'argv':argv(op),'required_hosts':NATIVE if op=='compile' else HOSTS} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'check':'accept','run':diag('E0600','oir-run'),'native':diag('E0700','native-admission')},'projection_scope':'Alias main points to original helper and does not synthesize original root main. Exact summary/code/stage/null diagnostic origins.'})
literal.append(add_success('child-main-is-ordinary',{'main.ox':b'mod child;\nfn main() -> i32 { return crate::child::answer(); }\n','child.ox':b'pub fn main(x: i32) -> i32 { return x + 10; }\npub fn answer() -> i32 { return main(2); }\n'},3,12,hosts=NATIVE,reason='Original root main calls child answer then ordinary child main(2), which accepts a parameter and returns 12. Child main never replaces root entry.'))

# Root/child artifact and decoding origins are distinct, before any checker.
for case_id,payload,code in [('invalid-utf8',b'\xff','E0003'),('oxbc-before-utf8',b'OXBC\xff','E0004')]:
 for child in [False,True]:
  files={'app.ox':b'mod a;\n','a.ox':payload} if child else {'main.ox':payload};entry='app.ox' if child else 'main.ox'
  name=('child-' if child else 'root-')+case_id;root,manifest=src(name,files);hosts=NATIVE if child else HOSTS
  counts={'app.ox':FILE_FULL,'a.ox':dict(zip(FP,[1,1,1,1,0,0,0,0]))} if child else {'main.ox':dict(zip(FP,[1,1,1,1,0,0,0,0]))}
  inherited.append({'id':name,'source_root':root,'entry':entry,'source_files':manifest,'required_hosts':hosts,'expected_route':None,'expected_lifecycle':ZERO,'file_counts':counts,'operations':[{'argv':argv(op,entry),'required_hosts':hosts} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag(code,'source',loc(files,'app.ox',4,5) if child else None)},'projection_scope':'Exactly one diagnostic, exact code/stage/full primary/null secondary. Child error primary is the declaring mod name, never invented child bytes; root primary is null. Message text bounded but unspecified. OXBC recognition precedes UTF-8 rejection. No later source read or checker/tool/output.'})
for prefix,label in [(b'','ascii'),(('// é🦀\r\n').encode(),'unicode-crlf')]:
 files={'app.ox':b'mod a;\nmod absent;\n','a.ox':prefix+b'/*'};name='child-lex-'+label;root,manifest=src(name,files)
 inherited.append({'id':name,'source_root':root,'entry':'app.ox','source_files':manifest,'required_hosts':NATIVE,'expected_route':None,'expected_lifecycle':ZERO,'file_counts':{'app.ox':FILE_FULL,'a.ox':dict(zip(FP,[1,1,1,1,1,0,0,0]))},'operations':[{'argv':argv(op,'app.ox'),'required_hosts':NATIVE} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag('E0100','lex',loc(files,'a.ox',len(prefix),len(prefix)+2,1))},'projection_scope':'Exactly one unterminated-comment lexical diagnostic at the actual child byte span. UTF-8 prefix/CRLF shifts bytes and line/scalar columns independently. Derived from retained Unit1 child_lex_before_sibling expectation plus lossless trivia relocation. Message bounded but unspecified.'})
files={'main.ox':b'mod a;\nmod later;\n','a.ox':b'pub fn a() -> i32 { return 1; }\n','later.ox':b'pub fn later() -> i32 { return 99; }\n'};root,manifest=src('child-unreadable',files)
inherited.append({'id':'child-unreadable','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':NATIVE,'required_capabilities':['posix_regular_file_mode_denies_open_for_effective_identity'],'filesystem_setup':{'target':'a.ox','kind':'regular','temporary_mode_octal':'0000','before_candidate':'Verify bytes while readable, set mode0000, then independently prove a read-open by the effective candidate identity fails with permission denial. Source content cannot change.','after_candidate':'Restore original temporary fixture mode before hashing; preserve bytes and demonstrate no candidate chmod or other mutation.','unsupported':'If effective privilege/ACL/capability lets the candidate identity open mode0000 files, do not execute this row and do not count a pass. Retain explicit unsupported-capability receipt with proof; do not substitute missing file or E0005 nonregular policy.'},'expected_route':None,'expected_lifecycle':ZERO,'file_counts':{'main.ox':FILE_FULL,'a.ox':dict(zip(FP,[1,0,0,0,0,0,0,0]))},'operations':[{'argv':argv(op),'required_hosts':NATIVE,'required_capabilities':['posix_regular_file_mode_denies_open_for_effective_identity']} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag('E0002','source',loc(files,'main.ox',4,5))},'projection_scope':'Exactly one E0002/source at declaring mod name with no secondary; OS-cause prose bounded but unspecified. Failed child open then no later reads/checker/tools/output. Capability-unavailable is explicit unqualified coverage, never a successful host skip.'})

# Inclusive public source-read byte admission is separate from parser resources.
small=b'fn main() -> i32 { return 1; }\n'
small_tokens=[b'fn',b' ',b'main',b'(',b')',b' ',b'->',b' ',b'i32',b' ',b'{',b' ',b'return',b' ',b'1',b';',b' ',b'}',b'\n']
need(b''.join(small_tokens)==small,'source-byte base independent token inventory')
whole,remainder=divmod(1048576-len(small),65536);need(remainder>=4,'source-byte comment tail')
trivia_sizes=[65536]*whole+[remainder]
trivia=[b'/*'+b' '*(n-4)+b'*/' for n in trivia_sizes]
need(all(len(t)<=65536 for t in small_tokens+trivia),'source-byte token lengths')
need(len(small_tokens+trivia)+1<=100000,'source-byte token count plus EOF')
exact=small+b''.join(trivia);need(len(exact)==1048576,'source-byte exact bytes')
literal.append(add_success('source-byte-exact',{'main.ox':exact},1,1,flavor='OriginalSingleFile',reason='Exactly1,048,576 UTF-8 bytes: one original scalar main returning1 plus trailing trivia. Source bound is inclusive; padding changes only separately bounded block-comment trivia, not semantics.'))
literal[-1]['source_byte_boundary_inventory']={'total_bytes':len(exact),'base_token_lengths':[len(t) for t in small_tokens],'base_token_bytes_hex':[t.hex() for t in small_tokens],'padding_token_lengths':trivia_sizes,'padding_kind':'separate block-comment tokens','max_token_bytes':max(map(len,small_tokens+trivia)),'non_eof_token_count':len(small_tokens+trivia),'with_eof_token_count':len(small_tokens+trivia)+1,'derivation':'Each block starts /* and ends */ with spaces inside; adjacent complete comments do not merge. The final comment length is the exact remaining byte budget. No current lexer invocation used.'}
files={'main.ox':b' '*1048577};root,manifest=src('source-byte-over',files)
inherited.append({'id':'source-byte-over','source_root':root,'entry':'main.ox','source_files':manifest,'required_hosts':HOSTS,'expected_route':None,'expected_lifecycle':ZERO,'file_counts':{'main.ox':dict(zip(FP,[1,1,1,0,0,0,0,0]))},'operations':[{'argv':argv(op),'required_hosts':HOSTS} for op in ['check','run','compile']],'literal_accepted_expected_projection':{'status':'reject',**diag('E0400','source')},'projection_scope':'Exactly one source byte-cap diagnostic, null primary/empty secondary, status1, no output or tool/lex/parse/checker work. Input bytes preserved. Retained lifecycle root-byte-limit source/counter authority; diagnostic classification from published source-cap contract.'})

amend=read(REC/'lifecycle/lifecycle-amendment-v3.json');lifecycle=next(x['after'] for x in amend['corrections'] if x['path']=='/observation_lifecycle')
contract={'schema_version':1,'identity':'unit4-public-cli-replacement-v3','status':'NEW_SOURCE_ONLY_CONTRACT_AWAITING_INDEPENDENT_REVIEW','historical_nonidentity':{'lost_parser_sha256':'2c2b44cf895c2499821a3cc7ab31f6244840a8a44e876a0f82006d84e1f2ed71','lost_public_sha256':'1cd3b42d2f93158e88b6a37ac99b89b9a10e85c926e2e7eb4d63675ab170073f','claim':'New contracts are not exact restoration of either lost file.'},'profiles':PROFILES,'declared_hosts':HOSTS,'host_normalization':{'Darwin':'macOS','AMD64':'x86_64','aarch64':'arm64'},'host_selection':'Normalize OS/architecture with explicit map, then exact set membership. Each case/operation declares its full host set. Exclusions are declared_hosts minus required_hosts, never inferred from IDs or prefixes.','literal_cases':literal,'inherited_negative_and_route_cases':inherited,'observation_lifecycle':lifecycle,'source_integrity':'Fresh materialization for each operation/profile; verify complete file map before/after; source and unrelated file bytes unchanged; consumer_source_reopens=0; no output on failure.','native_scope':{'hosts':NATIVE,'llvm_version':'19.1.7','opt_level':0,'profiles':PROFILES,'rules':'Admission/source/entry failures precede any tool invocation; no legacy/scalar/reference fallback. Successful native verifies real tool identities and output is x86_64 ELF. Copy only ELF to separate execution directory; remove materialized fixture sources during run and restore exact identities afterward.'},'coverage_companions':['original-compatibility-contract-replacement-v3.json.gz','predecessor-public-projections-replacement-v3.json.gz','lifecycle-contract-replacement-v3.json.gz','output-guards-contract-replacement-v3.json','pilot-semantic-derivations-v3.json'],'authoring':{'compiler_invocations':0,'candidate_result_files_read':0,'production_source_as_oracle':False,'predecessor_modifications':0,'remote_writes':0}}
contract['new_policy_diagnostic_bounds']={'authority':'RFC0015 section6.3','applies_to':[{'code':'E0005','stage':'source'},{'code':'E0205','stage':'resolve'},{'code':'E0206','stage':'resolve'},{'code':'E0206','stage':'type'},{'code':'E0207','stage':'resolve'},{'code':'E0400','stage':'source-project'},{'code':'E0400','stage':'resolve-project'}],'message_utf8_bytes_max':1024,'secondary_label_count_max':2,'secondary_label_message_utf8_bytes_max':256,'note_count_max':2,'note_utf8_bytes_max':256,'message_nonempty':True,'measurement':'UTF-8 encoded byte length, not Unicode scalar count. Exact diagnostic vectors and related-locations checks remain stronger where supplied.','E0002_exception':'Filesystem OS-cause text is not made literal and this new-policy-only constraint must not silently expand into an exact host suffix requirement.'}
contract['observation_inventory']={'required':'Fail closed before semantic comparison on zero, missing, extra, duplicate, false-skip, wrong-profile or wrong-host rows. Every contract-declared case/observation/profile/host tuple has exactly one receipt; excluded hosts have exactly one nonexecuted receipt with the exact scope reason.','key_fields':['contract_identity','group','case_id','observation_index','profile','canonical_host'],'scope':'Applies to main, original compatibility, all predecessor projections, lifecycle heldouts/public observations, occupied guards and post-link race controls. Successful native operations additionally require exactly one source-free execution envelope bound to that compile receipt.','derive_scope':'Per-observation required_hosts overrides case scope; profiles is explicit. Do not flatten duplicate operations in differing formats or use case IDs/prefixes for host selection.'}
save(OUT/'public-cli-contract-replacement-v3.json',contract)
# Lifecycle heldouts are copied from retained independently authored source bytes,
# stored compactly; no huge source hex is repeated in more than one artifact.
h=read(REC/'lifecycle/heldout-lifecycle-expectations.reconstructed-source-only-v1.json');held=h['heldout_cases'];need(len(held)==15,'all heldouts')
for row in held:
 row['required_hosts']=NATIVE if row['id'] in ['child-lex-stops-later-read','child-utf8-stops-later-read','project-unused-child-type'] else HOSTS
 row['profiles']=PROFILES
public_lifecycle=[]
for row in literal+inherited:
 if 'file_counts' in row:
  public_lifecycle.append({k:row[k] for k in ['id','required_hosts','expected_lifecycle','file_counts','expected_route'] if k in row}|{'expected_flavor':({'OriginalSingleFile':'original','ProjectSyntax':'project'}.get(row.get('successful_flavor'))) if row['expected_lifecycle']['checker_attempts'] else None,'observations':[{'observation_index':i,'argv':x['argv'],'format':'json' if '--message-format=json' in x['argv'] else 'text','required_hosts':x.get('required_hosts',row['required_hosts']),'profiles':PROFILES,'required_capabilities':x.get('required_capabilities',row.get('required_capabilities',[]))} for i,x in enumerate(row.get('observations',row.get('operations',[])))]})
zipped(OUT/'lifecycle-contract-replacement-v3.json.gz',{'schema_version':1,'identity':'unit4-lifecycle-replacement-v3','observation_lifecycle':lifecycle,'counter_order':PHASES,'file_counter_order':FP,'source_read_definition':'One logical read sequence after successful open; completion means clean EOF before OXBC/UTF-8 validation. Not syscall count.','heldout_cases':held,'public_cases':public_lifecycle,'source_authority':bind(REC/'lifecycle/heldout-lifecycle-expectations.reconstructed-source-only-v1.json'),'authoring':{'compiler_invocations':0,'candidate_result_files_read':0}})
# All inherited rows remain present, including their limited historical projection.
u2lines=gzip.decompress((U2/'corpus.jsonl.gz').read_bytes()).splitlines(keepends=True);u2=[json.loads(x) for x in u2lines];need(len(u2)==3603,'all Unit2 rows');byid={x['id']:x for x in u2};lineby={x['id']:sha(l) for x,l in zip(u2,u2lines)}
redirect={'grammar-amendment/module-qualified-projection':'grammar-amendment/qualified-projection','grammar-amendment/original-qualified-borrow':'parser/qualified-borrow-place'}
projection=[]
for d in u2:
 reqraw=base64.b64decode(d['request_base64']);need(sha(reqraw)==d['request_sha256'],'Unit2 request hash');req=json.loads(reqraw)
 for s in d['sources']:
  b=base64.b64decode(s['base64']);need(len(b)==s['bytes'] and sha(b)==s['sha256'],'Unit2 source hash')
 a=byid[redirect[d['id']]] if d['id'] in redirect else d
 if d['id'] in redirect:need(d['sources']==a['sources'],'exact source redirect')
 e=a['expected']
 if d['mode']=='legacy-scalar':kind='schema-and-source-only';claims=[]
 elif 'diagnostics' in e:kind='complete-check-projection';claims=['status','diagnostic-count-order','code-stage-file-primary-secondary','literal-prose-when-frozen','check-summary']
 elif 'first_diagnostic' in e:kind='first-diagnostic-only';claims=['failure-status','first-code-stage']
 elif e.get('parser_accepts'):kind='front-end-prefix-only';claims=['no-source-lex-parse-error' if e.get('load_accepts') else 'no-root-lex-parse-error']
 else:raise ValueError('unmapped Unit2 '+d['id'])
 projection.append({'family':'Unit2','id':d['id'],'authority_id':a['id'],'source_line_sha256':lineby[d['id']],'expected_authority_line_sha256':lineby[a['id']],'kind':kind,'claims':claims,'entry':req['entry'],'source_files':[{k:s[k] for k in ['path','bytes','sha256']} for s in d['sources']],'operations':['check'],'profiles':PROFILES,'required_hosts':NATIVE,'expected_projection_sha256':sha(compact(e)),'excluded_assertions':['private-stage-counters','private-route-flavor','private-IDs-targets-imports','raw-events-fuel']+(['semantic-outcome'] if kind=='schema-and-source-only' else ['later-sequence'] if kind in ['first-diagnostic-only','front-end-prefix-only'] else [])})
for e,l in zip(expected,exlines):
 q=qby[e['id']];kind='first-source-failure-check-run-projection' if e['expected'].get('selection')=='one specified first source failure' else 'complete-check-run-projection'
 projection.append({'family':'Unit3','id':e['id'],'authority_id':e['id'],'expected_authority_line_sha256':sha(l),'kind':kind,'claims':['status','accepted-function-count','result-type-value-or-diagnostic','frozen-code-stage-file-primary-secondary'],'entry':q['entry'],'source_files':q['source_files'],'operations':['check','run'],'profiles':PROFILES,'required_hosts':NATIVE,'expected_projection_sha256':sha(compact(e['expected'])),'excluded_assertions':['private-stage-counters','private-route-flavor','private-IDs-targets-imports','raw-events-fuel']+(['later-sequence'] if kind.startswith('first-') else [])})
zipped(OUT/'predecessor-public-projections-replacement-v3.json.gz',{'schema_version':1,'identity':'unit4-predecessor-public-projections-replacement-v3','unit2_cases':3603,'unit3_cases':152,'rows':projection,'kind_counts':dict(collections.Counter(r['kind'] for r in projection)),'no_historical_receipt_retarget':True,'unchanged_internal_obligations':'All original Unit1/2/3 private/index/raw/event/fuel/native controls remain required where applicable. These new public projections neither replace nor weaken original contracts.','source_only_retained_adapter_basis':bind(REC/'public-qualification/prepare_predecessor_projection.py'),'compiler_invocations':0,'candidate_result_files_read':0})
# Guards use complete frozen Unit3 diagnostic streams and source-preservation rules.
sup=read(O3/'supplements/native-diagnostics-v1/expectations.json');guardreq=read(REC/'public-qualification/source-only-inputs/no-clobber-requests.json')['requests'];guards=[]
for i,r in enumerate(guardreq):
 if r['id'].startswith('negative-native_recursion'):
  envelope=next(x for c in sup['driver'] if c['id']==r['id'] for x in c['expectations'] if x['operation']=='compile' and x['format']==r['format'])
 else:envelope=next(x for c in sup['no_clobber'] if c['id']==r['id'] and c['output_kind']==r['output_kind'] for x in c['expectations'] if x['format']==r['format'])
 guards.append({'id':f'occupied-output-{i}','source_case_id':r['id'],'profiles':r['profiles'],'required_hosts':NATIVE,'output_kind':r['output_kind'],'format':r['format'],'frozen_envelope':envelope,'expected_tools':0,'expected_lifecycle':FULL,'source_files':qby[r['id']]['source_files'],'expected_preservation':'Exact sources, regular output bytes or symlink target/link identity and target bytes unchanged; no new native workspace remains.','entry_template':'${FIXTURE_ROOT}/'+r['id']+'/'+qby[r['id']]['entry'],'output_template':'${OUTPUT}'})
save(OUT/'output-guards-contract-replacement-v3.json',{'schema_version':1,'identity':'unit4-output-guards-replacement-v3','occupied_controls':guards,'path_substitution':sup['path_substitution'],'source_authorities':[bind(O3/'supplements/native-diagnostics-v1/expectations.json'),bind(REC/'public-qualification/source-only-inputs/no-clobber-requests.json')],'concurrent_publication':{'id':'output-created-after-link','source_case_id':'pilot-scalar','profiles':PROFILES,'required_hosts':NATIVE,'initial_output':'absent','inject_after':'Successful real link; before compiler receives link completion','payload_hex':b'winner'.hex(),'payload_sha256':sha(b'winner'),'expected_status':1,'diagnostic_projection':diag('E0701','native-toolchain'),'summary':summary('compile',None,False,1),'stdout_mode':'JSON diagnostic then exact compile-summary line; host I/O cause message is a nonliteral projection','stderr':'','expected_directory_delta':['out.bin'],'expected_lifecycle':FULL,'preserve_output_inode_and_bytes':True,'expected_native_workspaces_after':[],'execute_linked_elf':False,'source_basis':'native-preview.md: atomic hard-link publication fails if any destination already exists, including created after preflight. This new race expectation does not claim recovery of lost c9b7d968 supplement or exact host error wording.','trace_requirements':['pin actual tool binaries/version19.1.7/O0','capture real successful link before injection','exclusive O_CREAT|O_EXCL competing write','read-back competitor bytes/identity','compiler publication fails without replacement','source hashes unchanged','scratch cleanup'], 'denial_before_tools_applicability':'Only pre-admission/occupied-output failures require zero tools. This injected post-link publication failure intentionally occurs after tools.'},'compiler_invocations':0,'candidate_result_files_read':0})
# Bind full pilot model rows without duplicating their large schedules/events.
pilotrows=[]
for name in pilots:
 e=eby[name];i=expected.index(e)
 pilotrows.append({'id':name,'expected_line_1_based':i+1,'expected_line_including_lf_sha256':sha(exlines[i]),'source_files':qby[name]['source_files'],'entry':e['entry'],'route':e['route'],'function_count':e['function_count'],'result':e['expected'],'source_reasoning':reasons[name],'budget_points':[x['budget'] for x in e.get('budget_cases',[])],'complete_execution_fuel':e['schedule']['total_fuel'],'activations':e['dynamic']['activations'],'owner_generations':e['dynamic']['generations'],'full_schedule_scope':'Use the complete unchanged independent Unit3 expected row for schedule, operation/effect order, per-budget failures, raw/source map, correspondence and native admission. This summary does not claim those details from CLI alone.'})
save(OUT/'pilot-semantic-derivations-v3.json',{'schema_version':1,'identity':'unit4-pilot-derivations-v3','pilot_rows':pilotrows,'authority':bind(O3/'expected.jsonl.gz'),'source_transport':bind(U3/'source-transport/sources.tar.gz'),'compiler_invocations':0,'candidate_result_files_read':0})
allow=[REPO/'rfcs/0015-bounded-typed-projects.md',REPO/'rfcs/0014-owned-structs-call-borrows.md',REPO/'spec/typed-preview.md',REPO/'spec/native-preview.md',REC/'parser/IMPLEMENTATION.md',REC/'lifecycle/lifecycle-amendment-v3.json',REC/'lifecycle/heldout-lifecycle-expectations.reconstructed-source-only-v1.json',FX/'typed_project_unit1_independent/expected-fixtures.json',FX/'typed_project_unit1_independent/materialize_fixtures.py',U1/'suite-intent.json',U1/'expected-results.json',U1/'generate_fixtures.py',U2/'package-manifest.json',U2/'corpus-manifest.json',U2/'corpus.jsonl.gz',U2/'original93-prose-expectations.json',U2/'legacy-scalar-schedule-clarification.json',O3/'pre-execution-manifest.json',O3/'requests.jsonl',O3/'expected.jsonl.gz',U3/'source-transport/sources.tar.gz',O3/'supplements/native-diagnostics-v1/expectations.json',REC/'public-qualification/source-only-inputs/no-clobber-requests.json',REC/'public-qualification/prepare_predecessor_projection.py']
save(OUT/'authority-bindings-replacement-v3.json',{'schema_version':1,'identity':'unit4-public-authorities-replacement-v3','bindings':[bind(p) for p in allow],'provenance':'Only published normative specifications and unchanged independently authored expectation assets; no candidate-produced outputs accepted as oracle. Unit1 complete baseline stream expectations are preserved predecessor authority, never current candidate captures.','authoring':{'compiler_invocations':0,'candidate_result_files_read':0,'production_source_as_oracle':False}})
files=[bind(p) for p in sorted(OUT.glob('*')) if p.is_file() and p.name!='PUBLIC-FREEZE-v3.json']
for row in files:
 if row['path'].endswith('.gz'):
  b=gzip.decompress(pathlib.Path(row['path']).read_bytes());row.update(decoded_bytes=len(b),decoded_sha256=sha(b))
save(OUT/'PUBLIC-FREEZE-v3.json',{'schema_version':1,'status':'NEW_SOURCE_ONLY_EXPECTATIONS_AWAITING_INDEPENDENT_REVIEW','generator':bind(pathlib.Path(__file__)),'validator':bind(ROOT/'validate_public_contracts_v3.py'),'files':files,'counts':{'original_compatibility_cases':len(original),'literal_activation_cases':len(literal),'inherited_negative_route_host_cases':len(inherited),'heldout_lifecycle_cases':len(held),'unit2_preserved':len(u2),'unit3_preserved':len(expected),'occupied_output_controls':len(guards),'concurrent_output_controls':1},'compiler_invocations':0,'candidate_result_files_read':0,'historical_full_contract_recovery_claim':False})
print(json.dumps({'freeze':bind(OUT/'PUBLIC-FREEZE-v3.json'),'counts':read(OUT/'PUBLIC-FREEZE-v3.json')['counts']},indent=2))
