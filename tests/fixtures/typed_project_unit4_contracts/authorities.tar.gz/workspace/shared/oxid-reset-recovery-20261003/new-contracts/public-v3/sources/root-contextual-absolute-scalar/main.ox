fn crate() -> i32 { return 4; } fn as() -> i32 { return 6; }
use crate::crate as selected;
pub fn main() -> i32 { return selected() + crate::as(); }
