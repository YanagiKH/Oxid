fn first(x: Missing) -> i32 { return 1; }
struct Record { a: i32, a: bool }
fn next(x: AlsoMissing) -> i32 { return 2; }
