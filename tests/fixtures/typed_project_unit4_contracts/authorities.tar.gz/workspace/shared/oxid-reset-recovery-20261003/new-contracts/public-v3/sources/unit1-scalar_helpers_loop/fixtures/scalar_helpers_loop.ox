fn step(x: i32) -> i32 { return x * 2; }
fn main() -> i32 { let mut total = 1; let mut index = 0; while index < 4 { total = step(total) + index; index = index + 1; } return total; }
