struct as { n: i32 }
struct crate { n: i32 }
struct self { n: i32 }
struct super { n: i32 }
fn as() -> i32 { return 2; }
fn crate() -> i32 { return 3; }
fn self() -> i32 { return 5; }
fn super() -> i32 { return 7; }
fn main() -> i32 {
    let a: as = as { n: as() };
    let b: crate = crate { n: crate() };
    let c: self = self { n: self() };
    let d: super = super { n: super() };
    return a.n + b.n + c.n + d.n;
}
