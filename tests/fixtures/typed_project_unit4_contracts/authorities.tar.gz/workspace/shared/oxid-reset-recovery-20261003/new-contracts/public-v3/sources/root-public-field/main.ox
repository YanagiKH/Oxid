pub struct Item { pub value: i32 }
pub fn main() -> i32 { let item = Item { value: 7 }; return item.value; }
