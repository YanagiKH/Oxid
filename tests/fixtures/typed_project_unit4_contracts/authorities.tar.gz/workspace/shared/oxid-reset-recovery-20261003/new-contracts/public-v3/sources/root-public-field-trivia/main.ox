// é🦀
pub struct Item { pub /* 雪 */ value: i32 }
pub fn main() -> i32 { let item = Item { value: 7 }; return item.value; }
