fn answer() -> i32 { return 13; } fn main() -> i32 { return crate::answer(); }
