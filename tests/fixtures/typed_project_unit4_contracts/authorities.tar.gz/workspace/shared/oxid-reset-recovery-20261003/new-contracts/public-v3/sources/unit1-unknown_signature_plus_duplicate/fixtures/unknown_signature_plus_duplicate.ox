fn same(x: Missing) -> i32 { return 1; }
fn same() -> i32 { return 2; }
fn main() -> i32 { return 3; }
