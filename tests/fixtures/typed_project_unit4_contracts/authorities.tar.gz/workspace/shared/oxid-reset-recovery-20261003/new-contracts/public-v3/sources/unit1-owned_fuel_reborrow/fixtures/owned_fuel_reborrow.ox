struct S { n: i32 } fn idle(p: &mut S) -> () { return; } fn pass(p: &mut S) -> () { idle(&mut *p); return; } fn main() -> i32 { let mut s = S { n: 1 }; while true { pass(&mut s); } return s.n; }
