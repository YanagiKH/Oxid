pub fn main(x: i32) -> i32 { return x + 10; }
pub fn answer() -> i32 { return main(2); }
