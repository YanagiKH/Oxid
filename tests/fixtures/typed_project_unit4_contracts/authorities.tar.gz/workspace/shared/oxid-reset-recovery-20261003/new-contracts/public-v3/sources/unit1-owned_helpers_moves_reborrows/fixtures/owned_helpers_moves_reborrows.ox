struct Counter { n: i32 }
fn make(n: i32) -> Counter { return Counter { n: n }; }
fn bump(p: &mut Counter) -> () { p.n = p.n + 2; return; }
fn relay_borrow(p: &mut Counter) -> () { bump(&mut *p); return; }
fn read(p: &Counter) -> i32 { return p.n; }
fn shared_reborrow(p: &mut Counter) -> i32 { return read(&*p); }
fn relay(p: Counter) -> Counter { return p; }
fn finish(p: Counter) -> i32 { return p.n; }
fn main() -> i32 { let mut value = make(3); relay_borrow(&mut value); bump(&mut value); let seen = shared_reborrow(&mut value); let moved = relay(value); return seen + finish(moved); }
