/*é*/fn same() -> i32 { return 1; }
/*雪*/fn same() -> i32 { return 2; }
