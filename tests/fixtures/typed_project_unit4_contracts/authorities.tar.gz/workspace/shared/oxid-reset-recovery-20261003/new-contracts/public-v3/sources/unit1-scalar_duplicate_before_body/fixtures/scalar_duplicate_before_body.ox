fn repeat() -> bool { return 1; }
fn repeat() -> i32 { return 2; }
fn main() -> i32 { return missing; }
