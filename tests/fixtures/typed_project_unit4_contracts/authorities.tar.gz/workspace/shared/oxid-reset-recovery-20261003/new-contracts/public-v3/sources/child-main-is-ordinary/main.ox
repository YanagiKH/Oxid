mod child;
fn main() -> i32 { return crate::child::answer(); }
