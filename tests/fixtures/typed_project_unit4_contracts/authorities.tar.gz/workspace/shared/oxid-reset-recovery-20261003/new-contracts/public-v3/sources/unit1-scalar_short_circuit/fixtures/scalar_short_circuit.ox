fn danger() -> bool { return 2147483647 + 1 == 0; } fn main() -> bool { return false && danger(); }
