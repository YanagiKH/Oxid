/*xx*/fn same() -> i32 { return 1; }
/*xxx*/fn same() -> i32 { return 2; }
