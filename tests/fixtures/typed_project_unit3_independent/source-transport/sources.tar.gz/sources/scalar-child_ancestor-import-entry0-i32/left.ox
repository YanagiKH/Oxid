use crate::helper as target_import;
pub fn bridge() -> i32 {
    return target_import(4) + 2;
}
