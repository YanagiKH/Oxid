pub fn answer(n: i32) -> i32 {
    return n + 1;
}
