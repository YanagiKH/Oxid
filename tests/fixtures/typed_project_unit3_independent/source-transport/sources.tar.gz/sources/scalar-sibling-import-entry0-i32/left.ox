use crate::right::helper as target_import;
pub fn bridge() -> i32 {
    return target_import(4) + 2;
}
pub fn helper(n: i32) -> i32 {
    return 91;
}
