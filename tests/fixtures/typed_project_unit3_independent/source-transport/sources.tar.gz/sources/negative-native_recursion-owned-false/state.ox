pub fn left(n: i32) -> i32 {
    if n < 1 {
        return 0;
    } else {
        return crate::other::right(n - 1) + 1;
    }
}
