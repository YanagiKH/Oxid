fn helper() -> i32 {
    return 99;
}
fn main() -> i32 {
    return sum(4) + choose(false, 7, 2);
}
fn choose(flag: bool, first: i32, second: i32) -> i32 {
    if flag {
        return first;
    } else {
        return second;
    }
}
fn inc(value: i32) -> i32 {
    return value + 1;
}
fn child_main(value: i32) -> i32 {
    return value + 1000;
}
fn sum(n: i32) -> i32 {
    let mut i = 0;
    let mut total = 0;
    while i < n {
        i = inc(i);
        if i == 2 {
            continue;
        }
        total = total + i;
        if total > 6 {
            break;
        }
    }
    return total;
}
