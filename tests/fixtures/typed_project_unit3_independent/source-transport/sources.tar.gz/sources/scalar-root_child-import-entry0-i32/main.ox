mod left;
mod right;
use crate::left::helper as target_import;
fn main() -> i32 {
    return target_import(4) + 2;
}
