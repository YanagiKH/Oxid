mod left;
mod right;
use crate::left::bridge as bridge_import;
fn root_prefix() -> bool {
    return false;
}
fn main() -> bool {
    return bridge_import();
}
