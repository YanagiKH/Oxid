mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    let mut x = Cell { value: 4 };
    crate::left::helper(&mut x);
    return crate::left::helper(&mut x);
}
