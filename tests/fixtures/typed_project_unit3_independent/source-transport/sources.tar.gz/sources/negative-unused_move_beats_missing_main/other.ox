pub fn unused() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    let mut y = crate::state::Cell { value: 7 };
    let z = crate::state::relay(x);
    return crate::state::read(&x);
}
