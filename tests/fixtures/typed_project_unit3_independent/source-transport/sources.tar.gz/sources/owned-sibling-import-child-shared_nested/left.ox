use crate::right::read as read_import;
use crate::right::helper as target_import;
pub fn bridge() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return target_import(&x, read_import(&x));
}
pub fn helper(p: &crate::state::Cell, n: i32) -> i32 {
    return 91;
}
