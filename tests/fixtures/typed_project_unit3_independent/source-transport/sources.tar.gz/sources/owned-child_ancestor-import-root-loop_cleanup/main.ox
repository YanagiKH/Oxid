mod left;
mod right;
use crate::left::bridge as bridge_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return bridge_import();
}
fn make(n: i32) -> Cell {
    return Cell { value: n };
}
fn helper(p: Cell) -> Cell {
    return p;
}
fn finish(p: Cell) -> i32 {
    return p.value;
}
