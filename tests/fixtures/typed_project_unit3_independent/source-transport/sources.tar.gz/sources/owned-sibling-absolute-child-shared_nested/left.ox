pub fn bridge() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return crate::right::helper(&x, crate::right::read(&x));
}
pub fn helper(p: &crate::state::Cell, n: i32) -> i32 {
    return 91;
}
