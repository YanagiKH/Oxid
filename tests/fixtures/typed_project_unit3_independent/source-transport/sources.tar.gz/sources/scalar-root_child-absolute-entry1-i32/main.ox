mod left;
mod right;
fn root_prefix() -> i32 {
    return 97;
}
fn main() -> i32 {
    return crate::left::helper(4) + 2;
}
