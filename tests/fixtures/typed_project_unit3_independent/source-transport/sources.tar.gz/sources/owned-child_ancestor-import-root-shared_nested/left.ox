use crate::read as read_import;
use crate::helper as target_import;
pub fn bridge() -> i32 {
    let x = crate::Cell { value: 4 };
    return target_import(&x, read_import(&x));
}
