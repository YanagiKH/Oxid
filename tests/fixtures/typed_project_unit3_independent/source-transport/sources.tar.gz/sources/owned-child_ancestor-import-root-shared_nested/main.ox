mod left;
mod right;
use crate::left::bridge as bridge_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return bridge_import();
}
fn helper(p: &Cell, n: i32) -> i32 {
    return p.value + n;
}
fn read(p: &Cell) -> i32 {
    return p.value;
}
