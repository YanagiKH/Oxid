mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    let x = Cell { value: 4 };
    return crate::left::helper(&x, crate::left::read(&x));
}
