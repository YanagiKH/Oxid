pub fn helper(p: &crate::Cell, n: i32) -> i32 {
    return p.value + n;
}
pub fn read(p: &crate::Cell) -> i32 {
    return p.value;
}
