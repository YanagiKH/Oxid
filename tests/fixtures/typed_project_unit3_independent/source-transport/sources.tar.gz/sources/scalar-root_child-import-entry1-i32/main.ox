mod left;
mod right;
use crate::left::helper as target_import;
fn root_prefix() -> i32 {
    return 97;
}
fn main() -> i32 {
    return target_import(4) + 2;
}
