mod state;
mod other;
fn main() -> i32 {
    return crate::state::left(3);
}
