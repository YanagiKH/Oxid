mod left;
mod right;
use crate::left::finish as finish_import;
use crate::left::make as make_import;
use crate::left::helper as target_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    make_import(90);
    let x = make_import(4);
    let y = target_import(target_import(x));
    return finish_import(y);
}
