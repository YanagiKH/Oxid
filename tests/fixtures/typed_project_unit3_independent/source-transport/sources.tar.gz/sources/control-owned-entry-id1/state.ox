pub struct Counter { value: i32 }
pub fn make(value: i32) -> Counter { return Counter { value: value }; }
pub fn bump(value: &mut Counter) -> () { value.value = value.value + 1; return; }
pub fn finish(value: Counter) -> i32 { return value.value; }
pub fn main(value: Counter) -> Counter { return value; }
