pub fn helper(p: crate::state::Cell) -> crate::state::Cell {
    return crate::state::Cell { value: 91 };
}
