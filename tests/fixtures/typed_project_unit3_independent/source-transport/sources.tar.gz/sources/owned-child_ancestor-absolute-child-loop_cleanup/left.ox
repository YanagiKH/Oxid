pub fn bridge() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = crate::make(i);
        let z = crate::helper(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + crate::finish(z);
    }
    return total;
}
