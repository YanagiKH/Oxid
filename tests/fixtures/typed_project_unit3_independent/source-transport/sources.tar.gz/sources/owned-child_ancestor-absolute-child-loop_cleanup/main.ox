mod left;
mod right;
mod state;
fn main() -> i32 {
    return crate::left::bridge();
}
fn make(n: i32) -> crate::state::Cell {
    return crate::state::Cell { value: n };
}
fn helper(p: crate::state::Cell) -> crate::state::Cell {
    return p;
}
fn finish(p: crate::state::Cell) -> i32 {
    return p.value;
}
