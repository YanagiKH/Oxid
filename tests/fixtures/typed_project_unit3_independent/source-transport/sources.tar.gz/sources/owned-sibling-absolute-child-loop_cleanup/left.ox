pub fn bridge() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = crate::right::make(i);
        let z = crate::right::helper(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + crate::right::finish(z);
    }
    return total;
}
pub fn helper(p: crate::state::Cell) -> crate::state::Cell {
    return crate::state::Cell { value: 91 };
}
