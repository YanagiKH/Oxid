mod left;
mod right;
mod state;
use crate::left::read as read_import;
use crate::left::helper as target_import;
fn main() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return target_import(&x, read_import(&x));
}
