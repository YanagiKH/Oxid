mod left;
mod right;
use crate::left::helper as target_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    let mut x = Cell { value: 4 };
    target_import(&mut x);
    return target_import(&mut x);
}
