pub fn bridge() -> i32 {
    crate::right::make(90);
    let x = crate::right::make(4);
    let y = crate::right::helper(crate::right::helper(x));
    return crate::right::finish(y);
}
pub fn helper(p: crate::Cell) -> crate::Cell {
    return crate::Cell { value: 91 };
}
