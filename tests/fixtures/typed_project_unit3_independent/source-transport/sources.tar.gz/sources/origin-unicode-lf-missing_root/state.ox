// 雪🦀
pub fn main() -> i32 { return 0; }
