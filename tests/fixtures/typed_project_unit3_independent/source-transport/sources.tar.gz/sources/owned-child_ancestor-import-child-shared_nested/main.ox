mod left;
mod right;
mod state;
use crate::left::bridge as bridge_import;
fn main() -> i32 {
    return bridge_import();
}
fn helper(p: &crate::state::Cell, n: i32) -> i32 {
    return p.value + n;
}
fn read(p: &crate::state::Cell) -> i32 {
    return p.value;
}
