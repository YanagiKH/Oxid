mod left;
mod right;
use crate::left::helper as target_import;
use crate::left::trap as trap_import;
fn main() -> bool {
    return target_import(false) || trap_import();
}
