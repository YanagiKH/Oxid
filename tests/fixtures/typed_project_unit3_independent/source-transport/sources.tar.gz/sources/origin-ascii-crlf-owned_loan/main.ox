// layout
mod state;
fn main() -> i32 { let mut x = crate::state::make(); return crate::state::pair(&mut x, x.value); }
