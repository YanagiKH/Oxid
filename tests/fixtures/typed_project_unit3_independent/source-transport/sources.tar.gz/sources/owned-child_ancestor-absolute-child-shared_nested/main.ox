mod left;
mod right;
mod state;
fn main() -> i32 {
    return crate::left::bridge();
}
fn helper(p: &crate::state::Cell, n: i32) -> i32 {
    return p.value + n;
}
fn read(p: &crate::state::Cell) -> i32 {
    return p.value;
}
