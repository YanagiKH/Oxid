pub fn bridge() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return crate::helper(&x, crate::read(&x));
}
