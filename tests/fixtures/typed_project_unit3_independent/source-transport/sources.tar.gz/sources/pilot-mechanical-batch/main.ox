mod state;
mod jobs;
use crate::state::Batch;
use crate::state::retry;
use crate::state::done;
use crate::state::relay;
use crate::state::finish;
use crate::jobs::dispatch;
fn main() -> i32 {
    let mut state = Batch { completed: 0, retries: 0, checksum: 0, active: true };
    while state.active {
        let mut attempt = 0;
        while attempt < 3 {
            attempt = attempt + 1;
            if attempt < 2 {
                retry(&mut state);
                continue;
            }
            let job = state.completed + 1;
            dispatch(&mut state, job);
            break;
        }
        if done(&state) {
            state.active = false;
            break;
        }
        continue;
    }
    let completed = relay(state);
    return finish(completed);
}
