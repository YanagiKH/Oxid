mod left;
mod right;
use crate::left::bridge as bridge_import;
fn root_prefix() -> bool {
    return false;
}
fn main() -> bool {
    return bridge_import();
}
fn helper(flag: bool) -> bool {
    return flag || true;
}
fn trap() -> bool {
    return 2147483647 + 1 > 0;
}
