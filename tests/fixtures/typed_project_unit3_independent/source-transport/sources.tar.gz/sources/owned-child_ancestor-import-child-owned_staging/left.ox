use crate::finish as finish_import;
use crate::make as make_import;
use crate::helper as target_import;
pub fn bridge() -> i32 {
    make_import(90);
    let x = make_import(4);
    let y = target_import(target_import(x));
    return finish_import(y);
}
