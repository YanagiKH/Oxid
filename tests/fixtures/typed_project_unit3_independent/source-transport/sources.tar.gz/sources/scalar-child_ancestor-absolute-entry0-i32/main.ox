mod left;
mod right;
fn main() -> i32 {
    return crate::left::bridge();
}
fn helper(n: i32) -> i32 {
    let mut i = 0;
    let mut sum = 0;
    while i < n {
        i = i + 1;
        if i == 2 {
            continue;
        }
        sum = sum + i;
        if sum > 6 {
            break;
        }
    }
    return sum;
}
