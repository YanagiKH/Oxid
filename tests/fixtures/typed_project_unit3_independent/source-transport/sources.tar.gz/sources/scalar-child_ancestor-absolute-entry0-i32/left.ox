pub fn bridge() -> i32 {
    return crate::helper(4) + 2;
}
