pub fn choose(flag: bool, first: i32, second: i32) -> i32 {
    if flag { return first; } else { return second; }
}
pub fn inc(value: i32) -> i32 { return value + 1; }
pub fn main(value: i32) -> i32 { return value + 1000; }
