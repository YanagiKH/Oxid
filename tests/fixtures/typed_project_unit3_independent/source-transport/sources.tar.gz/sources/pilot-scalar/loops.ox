use crate::maths::inc;
pub fn sum(n: i32) -> i32 {
    let mut i = 0;
    let mut total = 0;
    while i < n {
        i = inc(i);
        if i == 2 { continue; }
        total = total + i;
        if total > 6 { break; }
    }
    return total;
}
