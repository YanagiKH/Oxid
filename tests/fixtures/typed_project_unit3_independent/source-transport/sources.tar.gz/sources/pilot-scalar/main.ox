mod maths;
mod loops;
use crate::loops::sum;
fn helper() -> i32 { return 99; }
fn main() -> i32 { return sum(4) + crate::maths::choose(false, 7, 2); }
