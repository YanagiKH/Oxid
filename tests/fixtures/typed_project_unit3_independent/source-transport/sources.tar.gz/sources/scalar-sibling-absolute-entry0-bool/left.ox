pub fn bridge() -> bool {
    return crate::right::helper(false) || crate::right::trap();
}
pub fn helper(flag: bool) -> bool {
    return false;
}
