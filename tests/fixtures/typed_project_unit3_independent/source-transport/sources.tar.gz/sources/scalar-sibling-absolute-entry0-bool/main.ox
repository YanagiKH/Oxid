mod left;
mod right;
fn main() -> bool {
    return crate::left::bridge();
}
