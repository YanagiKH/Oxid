mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    crate::left::make(90);
    let x = crate::left::make(4);
    let y = crate::left::helper(crate::left::helper(x));
    return crate::left::finish(y);
}
