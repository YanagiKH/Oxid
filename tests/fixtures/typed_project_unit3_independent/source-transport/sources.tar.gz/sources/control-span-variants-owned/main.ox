mod state;
mod other;
pub struct Cell { pub value: i32, pub flag: bool }
fn main() -> i32 {
    let mut n = 3;
    n = n + 1;
    let yes = !false && true || false;
    let same = n == 4;
    crate::state::noop((n));
    let mut x = Cell { value: 1, flag: true };
    x = Cell { value: 4, flag: same };
    Cell { value: 90, flag: false };
    if yes {
        x.value = 5;
        let scratch = Cell { value: 11, flag: true };
    } else {
        x.value = 6;
        let scratch2 = Cell { value: 12, flag: false };
    }
    return x.value + n;
}
