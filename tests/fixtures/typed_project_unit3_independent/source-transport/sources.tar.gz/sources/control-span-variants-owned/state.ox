pub fn noop(n: i32) -> () {
    return;
}
