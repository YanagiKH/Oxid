mod state;
mod other;
fn main() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    let mut y = crate::state::Cell { value: 7 };
    return crate::state::pair(&x, crate::state::bump(&mut x));
}
