mod state;
mod other;
fn main() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    let mut y = crate::state::Cell { value: 7 };
    if true {
        crate::state::take(x);
    }
    return crate::state::read(&x);
}
