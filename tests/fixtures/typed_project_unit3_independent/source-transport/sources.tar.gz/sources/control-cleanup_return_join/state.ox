pub struct Cell { pub value: i32 }
pub fn choose(n: i32) -> Cell {
    let a = Cell { value: n };
    if n > 0 {
        let z = Cell { value: 9 };
        return a;
    }
    return a;
}
