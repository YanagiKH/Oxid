mod state;
mod other;
fn main() -> i32 {
    let a = crate::state::choose(4);
    let z = crate::state::choose(0);
    return a.value + z.value;
}
