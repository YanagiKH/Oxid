pub fn make(n: i32) -> crate::Cell {
    return crate::Cell { value: n };
}
pub fn helper(p: crate::Cell) -> crate::Cell {
    return p;
}
pub fn finish(p: crate::Cell) -> i32 {
    return p.value;
}
