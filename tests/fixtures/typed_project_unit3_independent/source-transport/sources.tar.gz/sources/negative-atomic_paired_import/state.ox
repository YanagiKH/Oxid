struct Dual { value: i32 }
pub fn Dual() -> i32 { return 4; }
