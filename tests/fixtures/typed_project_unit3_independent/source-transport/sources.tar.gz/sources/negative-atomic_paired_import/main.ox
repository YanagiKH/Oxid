mod state;
use crate::state::Dual;
fn main() -> i32 { return 0; }
