// layout
pub struct Cell { value: i32 }
pub fn make() -> Cell { return Cell { value: 0 }; }
pub fn overflow(p: &mut Cell) -> i32 { p.value = 7; return 2147483647 + 1; }
