mod left;
mod right;
mod state;
fn main() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = crate::left::make(i);
        let z = crate::left::helper(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + crate::left::finish(z);
    }
    return total;
}
