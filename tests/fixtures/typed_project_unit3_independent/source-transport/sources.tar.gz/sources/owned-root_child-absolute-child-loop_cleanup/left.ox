pub fn make(n: i32) -> crate::state::Cell {
    return crate::state::Cell { value: n };
}
pub fn helper(p: crate::state::Cell) -> crate::state::Cell {
    return p;
}
pub fn finish(p: crate::state::Cell) -> i32 {
    return p.value;
}
