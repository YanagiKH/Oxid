mod left;
mod right;
mod state;
fn main() -> i32 {
    return crate::left::bridge();
}
fn bump(p: &mut crate::state::Cell) -> () {
    p.value = p.value + 1;
    return;
}
fn helper(p: &mut crate::state::Cell) -> i32 {
    bump(&mut *p);
    bump(&mut *p);
    return p.value;
}
