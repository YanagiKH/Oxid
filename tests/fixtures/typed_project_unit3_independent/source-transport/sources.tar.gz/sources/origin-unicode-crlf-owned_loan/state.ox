// 雪🦀
pub struct Cell { pub value: i32 }
pub fn make() -> Cell { return Cell { value: 4 }; }
pub fn pair(p: &mut Cell, n: i32) -> i32 { return n; }
