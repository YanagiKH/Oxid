mod left;
mod right;
fn root_prefix() -> bool {
    return false;
}
fn main() -> bool {
    return crate::left::bridge();
}
