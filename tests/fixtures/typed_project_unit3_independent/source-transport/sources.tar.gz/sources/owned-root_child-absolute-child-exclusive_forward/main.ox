mod left;
mod right;
mod state;
fn main() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    crate::left::helper(&mut x);
    return crate::left::helper(&mut x);
}
