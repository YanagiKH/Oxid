pub fn bump(p: &mut crate::state::Cell) -> () {
    p.value = p.value + 1;
    return;
}
pub fn helper(p: &mut crate::state::Cell) -> i32 {
    bump(&mut *p);
    bump(&mut *p);
    return p.value;
}
