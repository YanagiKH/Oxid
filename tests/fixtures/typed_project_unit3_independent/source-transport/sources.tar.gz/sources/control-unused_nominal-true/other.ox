pub struct Unused {}
