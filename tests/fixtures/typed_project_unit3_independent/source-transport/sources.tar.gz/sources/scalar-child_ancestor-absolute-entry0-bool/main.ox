mod left;
mod right;
fn main() -> bool {
    return crate::left::bridge();
}
fn helper(flag: bool) -> bool {
    return flag || true;
}
fn trap() -> bool {
    return 2147483647 + 1 > 0;
}
