pub fn bridge() -> bool {
    return crate::helper(false) || crate::trap();
}
