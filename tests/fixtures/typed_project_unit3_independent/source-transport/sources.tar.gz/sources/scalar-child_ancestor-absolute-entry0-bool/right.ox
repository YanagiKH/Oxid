pub fn helper(flag: bool) -> bool {
    return false;
}
