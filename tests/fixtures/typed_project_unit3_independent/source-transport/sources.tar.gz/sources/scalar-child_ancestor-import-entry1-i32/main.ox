mod left;
mod right;
use crate::left::bridge as bridge_import;
fn root_prefix() -> i32 {
    return 97;
}
fn main() -> i32 {
    return bridge_import();
}
fn helper(n: i32) -> i32 {
    let mut i = 0;
    let mut sum = 0;
    while i < n {
        i = i + 1;
        if i == 2 {
            continue;
        }
        sum = sum + i;
        if sum > 6 {
            break;
        }
    }
    return sum;
}
