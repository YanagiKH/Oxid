mod state;
mod other;
fn main() -> i32 {
    let mut n = 3;
    n = n + 1;
    let yes = !false && true || false;
    let same = n == 4;
    crate::state::noop((n));
    if yes {
        n = 9;
    } else {
        n = 0;
    }
    return n;
}
