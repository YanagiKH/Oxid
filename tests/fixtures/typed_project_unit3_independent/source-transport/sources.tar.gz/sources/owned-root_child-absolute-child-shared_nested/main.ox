mod left;
mod right;
mod state;
fn main() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return crate::left::helper(&x, crate::left::read(&x));
}
