pub fn helper(p: &crate::state::Cell, n: i32) -> i32 {
    return p.value + n;
}
pub fn read(p: &crate::state::Cell) -> i32 {
    return p.value;
}
