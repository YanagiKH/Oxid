pub fn right(n: i32) -> i32 {
    if n < 1 {
        return 0;
    } else {
        return crate::state::left(n - 1) + 1;
    }
}
