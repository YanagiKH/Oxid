pub struct Cell { pub value: i32 }
pub fn target() -> Cell {
    return Cell { value: 4 };
}
