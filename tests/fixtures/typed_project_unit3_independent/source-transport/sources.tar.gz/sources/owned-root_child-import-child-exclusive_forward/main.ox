mod left;
mod right;
mod state;
use crate::left::helper as target_import;
fn main() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    target_import(&mut x);
    return target_import(&mut x);
}
