mod left;
mod right;
use crate::left::read as read_import;
use crate::left::helper as target_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    let x = Cell { value: 4 };
    return target_import(&x, read_import(&x));
}
