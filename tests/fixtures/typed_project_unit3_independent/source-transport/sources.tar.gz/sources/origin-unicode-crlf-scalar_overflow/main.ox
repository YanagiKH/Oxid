// 雪🦀
mod state;
fn main() -> i32 { return crate::state::overflow(); }
