pub struct Cell { pub value: i32 }
pub fn read(p: &Cell) -> i32 {
    return p.value;
}
pub fn take(p: Cell) -> i32 {
    return p.value;
}
pub fn relay(p: Cell) -> Cell {
    return p;
}
pub fn bump(p: &mut Cell) -> i32 {
    p.value = p.value + 1;
    return p.value;
}
pub fn pair(p: &mut Cell, n: i32) -> i32 {
    return n;
}
pub fn forward(p: &mut Cell) -> i32 {
    return pair(&mut *p, p.value);
}
