pub struct Cell { pub value: i32 }
pub fn target() -> Cell {
    return crate::other::Cell { value: 4 };
}
