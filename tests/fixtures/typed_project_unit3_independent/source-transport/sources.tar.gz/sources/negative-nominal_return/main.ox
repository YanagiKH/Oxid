mod state;
mod other;
fn main() -> i32 {
    let x = crate::state::target();
    return x.value;
}
