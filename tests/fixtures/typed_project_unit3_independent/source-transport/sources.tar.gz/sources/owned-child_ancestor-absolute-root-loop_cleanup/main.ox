mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return crate::left::bridge();
}
fn make(n: i32) -> Cell {
    return Cell { value: n };
}
fn helper(p: Cell) -> Cell {
    return p;
}
fn finish(p: Cell) -> i32 {
    return p.value;
}
