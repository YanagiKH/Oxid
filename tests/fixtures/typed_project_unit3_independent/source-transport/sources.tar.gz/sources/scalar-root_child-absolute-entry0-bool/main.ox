mod left;
mod right;
fn main() -> bool {
    return crate::left::helper(false) || crate::left::trap();
}
