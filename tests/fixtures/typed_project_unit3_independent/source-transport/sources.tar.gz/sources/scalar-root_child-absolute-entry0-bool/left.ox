pub fn helper(flag: bool) -> bool {
    return flag || true;
}
pub fn trap() -> bool {
    return 2147483647 + 1 > 0;
}
