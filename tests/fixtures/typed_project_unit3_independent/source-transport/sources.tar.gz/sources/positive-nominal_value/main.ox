mod state;
mod other;
fn main() -> i32 {
    let x = crate::state::Cell { value: 4 };
    return crate::state::target(x);
}
