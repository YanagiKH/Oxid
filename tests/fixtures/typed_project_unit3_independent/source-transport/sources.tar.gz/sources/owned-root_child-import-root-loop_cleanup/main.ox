mod left;
mod right;
use crate::left::finish as finish_import;
use crate::left::make as make_import;
use crate::left::helper as target_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = make_import(i);
        let z = target_import(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + finish_import(z);
    }
    return total;
}
