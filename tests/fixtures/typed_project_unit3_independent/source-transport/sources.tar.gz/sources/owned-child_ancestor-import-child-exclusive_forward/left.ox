use crate::helper as target_import;
pub fn bridge() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    target_import(&mut x);
    return target_import(&mut x);
}
