mod left;
mod right;
use crate::left::bridge as bridge_import;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return bridge_import();
}
