pub fn bridge() -> i32 {
    crate::make(90);
    let x = crate::make(4);
    let y = crate::helper(crate::helper(x));
    return crate::finish(y);
}
