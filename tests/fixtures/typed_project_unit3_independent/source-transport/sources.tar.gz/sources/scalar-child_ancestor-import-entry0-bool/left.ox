use crate::helper as target_import;
use crate::trap as trap_import;
pub fn bridge() -> bool {
    return target_import(false) || trap_import();
}
