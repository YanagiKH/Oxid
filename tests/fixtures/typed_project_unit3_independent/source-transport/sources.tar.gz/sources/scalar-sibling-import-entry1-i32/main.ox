mod left;
mod right;
use crate::left::bridge as bridge_import;
fn root_prefix() -> i32 {
    return 97;
}
fn main() -> i32 {
    return bridge_import();
}
