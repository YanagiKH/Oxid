mod state;
fn main() -> i32 { let mut x = crate::state::make(); x.value = true; return 0; }
