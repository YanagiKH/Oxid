mod state;
mod other;
fn main() -> i32 {
    let mut x = crate::state::Cell { value: 4 };
    let mut y = crate::state::Cell { value: 7 };
    let mut i = 0;
    while i < 2 {
        crate::state::take(x);
        i = i + 1;
        continue;
    }
    return 0;
}
