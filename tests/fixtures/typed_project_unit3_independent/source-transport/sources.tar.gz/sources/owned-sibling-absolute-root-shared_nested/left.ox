pub fn bridge() -> i32 {
    let x = crate::Cell { value: 4 };
    return crate::right::helper(&x, crate::right::read(&x));
}
pub fn helper(p: &crate::Cell, n: i32) -> i32 {
    return 91;
}
