mod state;
use crate::state::Counter;
use crate::state::make;
use crate::state::bump as increment;
use crate::state::finish;
fn main() -> i32 {
    let mut value: Counter = make(4);
    increment(&mut value);
    return finish(value);
}
