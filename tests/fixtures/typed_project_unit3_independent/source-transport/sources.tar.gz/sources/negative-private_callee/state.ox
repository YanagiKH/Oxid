fn secret() -> i32 { return 4; }
