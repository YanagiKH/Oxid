pub fn bridge() -> i32 {
    let mut x = crate::Cell { value: 4 };
    crate::helper(&mut x);
    return crate::helper(&mut x);
}
