mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return crate::left::bridge();
}
fn bump(p: &mut Cell) -> () {
    p.value = p.value + 1;
    return;
}
fn helper(p: &mut Cell) -> i32 {
    bump(&mut *p);
    bump(&mut *p);
    return p.value;
}
