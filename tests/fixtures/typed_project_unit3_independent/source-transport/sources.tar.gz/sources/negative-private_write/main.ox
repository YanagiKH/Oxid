mod state;
fn main() -> i32 { let mut x = crate::state::make(); x.value = 5; return 0; }
