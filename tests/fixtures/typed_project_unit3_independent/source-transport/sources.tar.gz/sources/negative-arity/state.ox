pub struct Cell { pub value: i32 }
pub fn target(n: i32) -> i32 {
    return n;
}
