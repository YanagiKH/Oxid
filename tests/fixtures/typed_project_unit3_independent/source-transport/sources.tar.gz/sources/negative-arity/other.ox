pub struct Cell { pub value: i32 }
