pub struct Cell { value: i32 }
pub fn make() -> Cell { return Cell { value: 4 }; }
