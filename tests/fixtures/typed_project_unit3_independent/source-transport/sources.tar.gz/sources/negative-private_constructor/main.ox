mod state;
fn main() -> i32 { let x = crate::state::Cell { value: 4 }; return 0; }
