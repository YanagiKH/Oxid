use crate::right::helper as target_import;
use crate::right::trap as trap_import;
pub fn bridge() -> bool {
    return target_import(false) || trap_import();
}
pub fn helper(flag: bool) -> bool {
    return false;
}
