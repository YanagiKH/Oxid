mod left;
mod right;
use crate::left::bridge as bridge_import;
fn main() -> bool {
    return bridge_import();
}
