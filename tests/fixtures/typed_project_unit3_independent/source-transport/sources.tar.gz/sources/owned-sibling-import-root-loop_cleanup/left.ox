use crate::right::finish as finish_import;
use crate::right::make as make_import;
use crate::right::helper as target_import;
pub fn bridge() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = make_import(i);
        let z = target_import(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + finish_import(z);
    }
    return total;
}
pub fn helper(p: crate::Cell) -> crate::Cell {
    return crate::Cell { value: 91 };
}
