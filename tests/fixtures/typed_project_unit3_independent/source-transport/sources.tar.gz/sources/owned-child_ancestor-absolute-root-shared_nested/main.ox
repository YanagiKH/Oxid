mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return crate::left::bridge();
}
fn helper(p: &Cell, n: i32) -> i32 {
    return p.value + n;
}
fn read(p: &Cell) -> i32 {
    return p.value;
}
