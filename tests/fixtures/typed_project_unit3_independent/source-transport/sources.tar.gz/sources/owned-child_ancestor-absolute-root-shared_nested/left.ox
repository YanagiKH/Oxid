pub fn bridge() -> i32 {
    let x = crate::Cell { value: 4 };
    return crate::helper(&x, crate::read(&x));
}
