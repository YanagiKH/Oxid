use crate::finish as finish_import;
use crate::make as make_import;
use crate::helper as target_import;
pub fn bridge() -> i32 {
    let mut total = 0;
    let mut i = 0;
    while i < 3 {
        let a = make_import(i);
        let z = target_import(a);
        i = i + 1;
        if i == 1 {
            continue;
        }
        if i == 3 {
            break;
        }
        total = total + finish_import(z);
    }
    return total;
}
