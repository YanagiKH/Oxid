mod left;
mod right;
use crate::left::helper as target_import;
use crate::left::trap as trap_import;
fn root_prefix() -> bool {
    return false;
}
fn main() -> bool {
    return target_import(false) || trap_import();
}
