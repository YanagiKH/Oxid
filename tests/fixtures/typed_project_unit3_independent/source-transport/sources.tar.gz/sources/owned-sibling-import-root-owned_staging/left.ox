use crate::right::finish as finish_import;
use crate::right::make as make_import;
use crate::right::helper as target_import;
pub fn bridge() -> i32 {
    make_import(90);
    let x = make_import(4);
    let y = target_import(target_import(x));
    return finish_import(y);
}
pub fn helper(p: crate::Cell) -> crate::Cell {
    return crate::Cell { value: 91 };
}
