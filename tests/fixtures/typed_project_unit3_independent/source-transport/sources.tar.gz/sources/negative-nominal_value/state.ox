pub struct Cell { pub value: i32 }
pub fn target(p: Cell) -> i32 {
    return p.value;
}
