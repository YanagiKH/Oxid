mod state;
mod other;
fn main() -> i32 {
    let x = crate::other::Cell { value: 4 };
    return crate::state::target(x);
}
