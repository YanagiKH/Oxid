mod left;
mod right;
pub struct Cell { pub value: i32 }
fn main() -> i32 {
    return crate::left::bridge();
}
