pub fn bridge() -> i32 {
    let mut x = crate::Cell { value: 4 };
    crate::right::helper(&mut x);
    return crate::right::helper(&mut x);
}
pub fn helper(p: &mut crate::Cell) -> i32 {
    return 91;
}
